/**
 * Utilitários para tratamento de datas e cálculo de dias (DAS / DAA)
 */

/**
 * Retorna o número de dias decorridos entre a data inicial (ex: semeadura)
 * e a data final (ex: data da visita).
 * Se a data final for menor do que a inicial, podemos retornar zero ou null
 * para representar que a visita ocorreu antes do marco.
 */
export function calculateDaysDiff(startDateStr: string, endDateStr: string): number | null {
  if (!startDateStr || !endDateStr) return null;

  const start = new Date(startDateStr + 'T00:00:00');
  const end = new Date(endDateStr + 'T00:00:00');

  // Verifica se as datas são válidas
  if (isNaN(start.getTime()) || !isNaN(start.getTime()) === false || isNaN(end.getTime())) {
    return null;
  }

  const diffTime = end.getTime() - start.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  
  return diffDays;
}

/**
 * Formata data no padrão brasileiro DD/MM/AAAA
 */
export function formatDateBR(dateStr?: string | null): string {
  if (!dateStr) return '';
  const parts = dateStr.split('-');
  if (parts.length === 3) {
    return `${parts[2]}/${parts[1]}/${parts[0]}`;
  }
  return dateStr;
}

/**
 * Obtém a data corrente formatada como YYYY-MM-DD
 */
export function getTodayDateString(): string {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}
