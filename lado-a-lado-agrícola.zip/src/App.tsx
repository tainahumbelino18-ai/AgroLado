import React, { useState, useEffect } from 'react';
import { Trial, Visit, VisitStatus } from './types';
import { INITIAL_TRIALS, INITIAL_VISITS } from './initialData';
import { TrialList } from './components/TrialList';
import { Cronograma } from './components/Cronograma';
import { Relatorios } from './components/Relatorios';
import { DashboardStats } from './components/DashboardStats';
import { Sprout, Calendar, FileText, LayoutDashboard, Database, RefreshCw, Layers } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('dashboard');

  // Trials state loaded from LocalStorage or seeded default values
  const [trials, setTrials] = useState<Trial[]>(() => {
    const saved = localStorage.getItem('lal_trials');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (err) {
        console.error('Erro ao ler testes salvos:', err);
      }
    }
    return INITIAL_TRIALS;
  });

  // Visits state loaded from LocalStorage or seeded default values
  const [visits, setVisits] = useState<Visit[]>(() => {
    const saved = localStorage.getItem('lal_visits');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (err) {
        console.error('Erro ao ler visitas salvas:', err);
      }
    }
    return INITIAL_VISITS;
  });

  // Save to LocalStorage whenever trials modify
  useEffect(() => {
    localStorage.setItem('lal_trials', JSON.stringify(trials));
  }, [trials]);

  // Save to LocalStorage whenever visits modify
  useEffect(() => {
    localStorage.setItem('lal_visits', JSON.stringify(visits));
  }, [visits]);

  // Handle adding new trial
  const handleAddTrial = (newTrial: Trial) => {
    setTrials(prev => [newTrial, ...prev]);
  };

  // Handle deleting trial
  const handleDeleteTrial = (id: string) => {
    setTrials(prev => prev.filter(t => t.id !== id));
  };

  // Handle editing/updating a trial and auto-syncing matching visits
  const handleEditTrial = (updatedTrial: Trial) => {
    setTrials(prev => prev.map(t => t.id === updatedTrial.id ? updatedTrial : t));
    
    // Auto-propagate details changes to any visits linked to this trial ID
    setVisits(prevVisits => prevVisits.map(v => {
      if (v.trialId === updatedTrial.id) {
        return {
          ...v,
          producerName: updatedTrial.producer,
          productUsed: updatedTrial.product,
          crop: updatedTrial.crop
        };
      }
      return v;
    }));
  };

  // Handle adding new visit
  const handleAddVisit = (newVisit: Visit) => {
    setVisits(prev => [newVisit, ...prev]);
  };

  // Handle deleting visit
  const handleDeleteVisit = (id: string) => {
    setVisits(prev => prev.filter(v => v.id !== id));
  };

  // Handle updating status (Pendente vs Realizada)
  const handleUpdateVisitStatus = (id: string, status: VisitStatus) => {
    setVisits(prev => prev.map(v => {
      if (v.id === id) {
        return { ...v, status };
      }
      return v;
    }));
  };

  // Clean whole DB to seed again
  const handleResetDatabase = () => {
    if (confirm('Deseja redefinir todo o sistema com os dados de demonstração originais? Seu progresso atual será perdido.')) {
      setTrials(INITIAL_TRIALS);
      setVisits(INITIAL_VISITS);
      setActiveTab('dashboard');
    }
  };

  return (
    <div className="min-h-screen bg-stone-50 text-stone-900 flex flex-col antialiased">
      {/* Upper Navigation Header bar */}
      <header className="sticky top-0 z-40 bg-stone-900 text-stone-100 border-b border-stone-800 shadow-sm no-print">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-14">
            
            {/* Logo / Title section */}
            <div className="flex items-center gap-2.5">
              <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse" />
              <div>
                <h1 className="text-sm font-bold tracking-tight flex items-center gap-1.5">
                  AgroField Pro
                  <span className="text-[9px] bg-green-600 text-white font-bold px-1.5 py-0.5 rounded-sm shrink-0 uppercase tracking-widest leading-none">
                    LAL v2.4
                  </span>
                </h1>
                <p className="text-[9px] text-stone-400 uppercase tracking-widest">Gestão de Lado a Lado</p>
              </div>
            </div>

            {/* Top Toolbar buttons */}
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono text-stone-400 bg-stone-800/80 px-2 py-0.5 rounded border border-stone-700 select-all">
                REF: 2026-06-01
              </span>
              <button
                onClick={handleResetDatabase}
                title="Redefinir Dados Demonstrativos"
                className="p-1.5 text-stone-400 hover:text-amber-500 hover:bg-stone-850 rounded border border-transparent transition cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
              </button>
            </div>

          </div>
        </div>
      </header>

      {/* Main Layout holding both the Content and the Left-Aligned Vertical Tab Navigation */}
      <div className="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 flex flex-col md:flex-row gap-6">
        
        {/* Vertical Tab Navigation (Fitted on the Left on Desktop) */}
        <nav id="app-navigation-bar" className="w-full md:w-64 shrink-0 no-print">
          <div className="bg-white border border-stone-200 rounded p-4 shadow-sm sticky top-20 space-y-2">
            <div className="pb-3 mb-2 border-b border-stone-100">
              <h3 className="text-[10px] font-bold text-stone-400 uppercase tracking-widest">
                Menu de Navegação
              </h3>
              <p className="text-[9px] text-green-700 mt-0.5">Gestão Técnica & Pró-Campo</p>
            </div>
            
            <button
              onClick={() => setActiveTab('dashboard')}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 text-xs font-bold rounded transition cursor-pointer border text-left ${
                activeTab === 'dashboard'
                  ? 'bg-green-700 text-white border-green-700 shadow-sm'
                  : 'text-stone-600 hover:text-green-800 hover:bg-green-50 border-transparent bg-transparent'
              }`}
            >
              <LayoutDashboard className={`w-4 h-4 shrink-0 ${activeTab === 'dashboard' ? 'text-white' : 'text-green-700'}`} />
              Painel Geral
            </button>

            <button
              onClick={() => setActiveTab('trials')}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 text-xs font-bold rounded transition cursor-pointer border text-left ${
                activeTab === 'trials'
                  ? 'bg-green-700 text-white border-green-700 shadow-sm'
                  : 'text-stone-600 hover:text-green-800 hover:bg-green-50 border-transparent bg-transparent'
              }`}
            >
              <Layers className={`w-4 h-4 shrink-0 ${activeTab === 'trials' ? 'text-white' : 'text-green-700'}`} />
              Registro de Testes
            </button>

            <button
              onClick={() => setActiveTab('cronograma')}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 text-xs font-bold rounded transition cursor-pointer border text-left ${
                activeTab === 'cronograma'
                  ? 'bg-green-700 text-white border-green-700 shadow-sm'
                  : 'text-stone-600 hover:text-green-800 hover:bg-green-50 border-transparent bg-transparent'
              }`}
            >
              <Calendar className={`w-4 h-4 shrink-0 ${activeTab === 'cronograma' ? 'text-white' : 'text-green-700'}`} />
              Cronograma de Visitas
            </button>

            <button
              onClick={() => setActiveTab('reports')}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 text-xs font-bold rounded transition cursor-pointer border text-left ${
                activeTab === 'reports'
                  ? 'bg-green-700 text-white border-green-700 shadow-sm'
                  : 'text-stone-600 hover:text-green-800 hover:bg-green-50 border-transparent bg-transparent'
              }`}
            >
              <FileText className={`w-4 h-4 shrink-0 ${activeTab === 'reports' ? 'text-white' : 'text-green-700'}`} />
              Relatórios de Visitas
            </button>
          </div>
        </nav>

        {/* Main Content Area */}
        <main className="flex-1 min-w-0 pb-14">
          {activeTab === 'dashboard' && (
            <DashboardStats 
              trials={trials} 
              visits={visits} 
              onNavigate={(tab) => setActiveTab(tab)} 
            />
          )}

          {activeTab === 'trials' && (
            <TrialList 
              trials={trials} 
              onAddTrial={handleAddTrial} 
              onDeleteTrial={handleDeleteTrial} 
              onEditTrial={handleEditTrial}
            />
          )}

          {activeTab === 'cronograma' && (
            <Cronograma 
              visits={visits} 
              trials={trials} 
              onAddVisit={handleAddVisit} 
              onDeleteVisit={handleDeleteVisit} 
              onUpdateVisitStatus={handleUpdateVisitStatus} 
            />
          )}

          {activeTab === 'reports' && (
            <Relatorios 
              visits={visits} 
              trials={trials} 
            />
          )}
        </main>

      </div>

      {/* Persistent minimalistic footer */}
      <footer className="bg-stone-900 text-stone-400 border-t border-stone-850 py-3.5 text-center text-[10px] uppercase tracking-widest mt-auto no-print font-mono">
        AgroField Pro © {new Date().getFullYear()} — Todos os direitos reservados
      </footer>
    </div>
  );
}

