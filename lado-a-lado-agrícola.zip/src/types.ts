export type TrialType = 'Nutri' | 'Bio' | 'Semente';
export type TrialStatus = 'Implantado' | 'Em Andamento' | 'Colhido' | 'Entregue';

export interface AdditionalProduct {
  id: string;
  name: string;
  category: 'Tche' | 'Padrão';
  harvestedArea?: number;
  bagsPerHa?: number;
}

export interface Trial {
  id: string;
  type: TrialType;
  producer: string;
  product: string;
  productTche?: string; // Produto Utilizado Tche
  productStandard?: string; // Produto Utilizado Padrão
  crop: string; // Cultura (soja, milho, algodão, etc.)
  sowingDate: string; // YYYY-MM-DD
  applicationDate?: string; // YYYY-MM-DD (opcional)
  harvestDate?: string; // YYYY-MM-DD
  farmName: string; // Nome da fazenda
  municipalityUf: string; // Município/UF
  createdAt: string;
  notes?: string; // Observações para acrescentar
  harvestedAreaTche?: number;      // Área colhida do Tche
  bagsPerHaTche?: number;          // Sacas/ha do Tche
  harvestedAreaStandard?: number;  // Área colhida do Padrão
  bagsPerHaStandard?: number;      // Sacas/ha do Padrão
  
  // Novos campos solicitados
  safra: string; // Safra (ex: "24/25", "23/24")
  filial: string; // Filial (ex: "Filial Cascavel")
  consultor: string; // Consultor responsável
  status: TrialStatus; // Status (Implantado, Em Andamento, Colhido, Entregue)
  convertedToSale?: boolean; // Se o teste foi convertido em venda
  saleValue?: number; // Valor estimado da venda convertida (R$)
  
  additionalProducts?: AdditionalProduct[]; // Produtos adicionais e produtividade vinculada
}

export type VisitStatus = 'realizada' | 'pendente';

export interface Visit {
  id: string;
  trialId: string;
  producerName: string; // Sincronizado do teste
  productUsed: string; // Sincronizado do teste
  crop: string; // Sincronizado da cultura do teste
  visitDate: string; // YYYY-MM-DD
  status: VisitStatus;
  notes?: string;
  das?: number | null; // Dias Após Semeadura
  daa?: number | null; // Dias Após Aplicação
  createdAt: string;
}
