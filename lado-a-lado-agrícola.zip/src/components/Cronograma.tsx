import React, { useState, useEffect } from 'react';
import { Trial, Visit, VisitStatus } from '../types';
import { calculateDaysDiff, formatDateBR, getTodayDateString } from '../utils';
import { 
  Calendar as CalendarIcon, 
  Plus, 
  ChevronLeft, 
  ChevronRight, 
  MapPin, 
  CheckCircle, 
  Clock, 
  Trash2, 
  Check, 
  Info,
  CalendarCheck,
  AlertCircle,
  CalendarDays,
  CalendarRange,
  Route
} from 'lucide-react';

interface CronogramaProps {
  visits: Visit[];
  trials: Trial[];
  onAddVisit: (visit: Visit) => void;
  onDeleteVisit: (id: string) => void;
  onUpdateVisitStatus: (id: string, status: VisitStatus) => void;
}

export function Cronograma({ visits, trials, onAddVisit, onDeleteVisit, onUpdateVisitStatus }: CronogramaProps) {
  const [showAddForm, setShowAddForm] = useState(false);
  
  // Form State
  const [selectedTrialId, setSelectedTrialId] = useState('');
  const [visitDate, setVisitDate] = useState(getTodayDateString());
  const [status, setStatus] = useState<VisitStatus>('pendente');
  const [notes, setNotes] = useState('');
  const [calculatedDas, setCalculatedDas] = useState<number | null>(null);
  const [calculatedDaa, setCalculatedDaa] = useState<number | null>(null);

  // Calendar/Weekly Navigation State
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedCalendarDate, setSelectedCalendarDate] = useState<string | null>(null);
  
  // View mode switcher state: 'monthly' or 'weekly'
  const [viewMode, setViewMode] = useState<'monthly' | 'weekly'>('weekly');

  // Sync automatic product, crop, DAS, and DAA based on Trial and Visit Date
  useEffect(() => {
    if (!selectedTrialId) {
      setCalculatedDas(null);
      setCalculatedDaa(null);
      return;
    }

    const trial = trials.find(t => t.id === selectedTrialId);
    if (trial) {
      const das = calculateDaysDiff(trial.sowingDate, visitDate);
      const daa = trial.applicationDate ? calculateDaysDiff(trial.applicationDate, visitDate) : null;
      setCalculatedDas(das);
      setCalculatedDaa(daa);
    } else {
      setCalculatedDas(null);
      setCalculatedDaa(null);
    }
  }, [selectedTrialId, visitDate, trials]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trial = trials.find(t => t.id === selectedTrialId);
    if (!trial) {
      alert('Por favor, selecione um teste de campo válido.');
      return;
    }

    const newVisit: Visit = {
      id: `visit-${Date.now()}`,
      trialId: selectedTrialId,
      producerName: trial.producer,
      productUsed: trial.product,
      crop: trial.crop,
      visitDate,
      status,
      notes: notes.trim() || undefined,
      das: calculatedDas,
      daa: calculatedDaa,
      createdAt: new Date().toISOString(),
    };

    onAddVisit(newVisit);
    
    // reset form
    setSelectedTrialId('');
    setVisitDate(getTodayDateString());
    setStatus('pendente');
    setNotes('');
    setShowAddForm(false);
  };

  // Calendar Month Logic
  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const handlePrevMonth = () => {
    setCurrentDate(new Date(year, month - 1, 1));
  };

  const handleNextMonth = () => {
    setCurrentDate(new Date(year, month + 1, 1));
  };

  // Weekly Schedule Logic
  // Get Sunday of the week corresponding to currentDate
  const getStartOfWeek = (date: Date) => {
    const d = new Date(date);
    const day = d.getDay();
    const diff = d.getDate() - day;
    return new Date(d.setDate(diff));
  };

  const startOfWeek = getStartOfWeek(currentDate);
  const endOfWeek = new Date(startOfWeek);
  endOfWeek.setDate(startOfWeek.getDate() + 6);

  const handlePrevWeek = () => {
    const d = new Date(currentDate);
    d.setDate(d.getDate() - 7);
    setCurrentDate(d);
  };

  const handleNextWeek = () => {
    const d = new Date(currentDate);
    d.setDate(d.getDate() + 7);
    setCurrentDate(d);
  };

  const handleSetToday = () => {
    setCurrentDate(new Date());
  };

  // Generate 7 days of the selected week
  const weeklyDays = Array.from({ length: 7 }).map((_, i) => {
    const d = new Date(startOfWeek);
    d.setDate(startOfWeek.getDate() + i);
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    const dateString = `${y}-${m}-${day}`;
    return {
      date: d,
      dateString,
      dayLabel: ['DOM', 'SEG', 'TER', 'QUA', 'QUI', 'SEX', 'SÁB'][i],
      fullName: ['Domingo', 'Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira', 'Sábado'][i]
    };
  });

  // Month names in Portuguese
  const monthNames = [
    'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
    'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
  ];

  // Days in week headers
  const weekdaysHeader = ['DOM', 'SEG', 'TER', 'QUA', 'QUI', 'SEX', 'SÁB'];

  // Calculate grid
  const firstDayOfMonth = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  const calendarDays: { day: number | null; dateString: string | null }[] = [];
  
  // Fill empty leading boxes
  for (let i = 0; i < firstDayOfMonth; i++) {
    calendarDays.push({ day: null, dateString: null });
  }

  // Fill actual calendar days
  for (let day = 1; day <= daysInMonth; day++) {
    const formattedDay = String(day).padStart(2, '0');
    const formattedMonth = String(month + 1).padStart(2, '0');
    const dateString = `${year}-${formattedMonth}-${formattedDay}`;
    calendarDays.push({ day, dateString });
  }

  // Pre-fetch selected trial info
  const activeTrial = trials.find(t => t.id === selectedTrialId);

  // Group visits by date
  const getVisitsForDate = (dateStr: string) => {
    return visits.filter(v => v.visitDate === dateStr);
  };

  // Filter lists: all vs pending vs realized
  const [listStatusFilter, setListStatusFilter] = useState<'all' | VisitStatus>('all');
  
  const filteredVisits = visits.filter(v => {
    if (listStatusFilter === 'all') return true;
    return v.status === listStatusFilter;
  });

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 id="schedule-header" className="text-lg font-bold tracking-tight text-stone-900 flex items-center gap-2">
            <CalendarCheck className="w-5 h-5 text-green-700" />
            Cronograma de Visitas Técnicas LAL
          </h2>
          <p className="text-xs text-stone-500">
            Organize seu cronograma semanal e acompanhe o desenvolvimento dos seus testes com DAS e DAA automáticos.
          </p>
        </div>
        
        <div className="flex flex-wrap items-center gap-2">
          {/* View mode switcher */}
          <div className="flex bg-stone-100 p-1 rounded border border-stone-200">
            <button
              onClick={() => setViewMode('weekly')}
              className={`px-3 py-1.5 text-xs font-bold rounded flex items-center gap-1.5 transition ${
                viewMode === 'weekly'
                  ? 'bg-green-700 text-white shadow-3xs'
                  : 'text-stone-550 hover:text-green-800'
              }`}
            >
              <CalendarDays className="w-3.5 h-3.5" />
              <span>Cronograma Semanal</span>
            </button>
            <button
              onClick={() => setViewMode('monthly')}
              className={`px-3 py-1.5 text-xs font-bold rounded flex items-center gap-1.5 transition ${
                viewMode === 'monthly'
                  ? 'bg-green-700 text-white shadow-3xs'
                  : 'text-stone-550 hover:text-green-800'
              }`}
            >
              <CalendarRange className="w-3.5 h-3.5" />
              <span>Calendário Mensal</span>
            </button>
          </div>

          <button
            id="btn-new-visit"
            onClick={() => setShowAddForm(!showAddForm)}
            className="flex items-center justify-center gap-2 px-3.5 py-1.5 bg-green-700 hover:bg-green-800 text-white text-xs font-bold rounded shadow-xs transition-all cursor-pointer uppercase tracking-wider border border-green-700"
          >
            {showAddForm ? 'Fechar Formulário' : (
              <>
                <Plus className="w-4 h-4" />
                Agendar Visita
              </>
            )}
          </button>
        </div>
      </div>

      {/* Trial selection warning if empty */}
      {trials.length === 0 && (
        <div className="bg-amber-50 border border-amber-200 text-amber-800 p-4 rounded flex items-start gap-3 text-xs">
          <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div>
            <p className="font-bold uppercase tracking-wider">Nenhum teste de campo registrado ainda!</p>
            <p className="mt-1">
              Para poder agendar uma visita e calcular o DAS ou DAA de forma sincronizada, você precisa primeiro registrar pelo menos um teste lado a lado na aba anterior.
            </p>
          </div>
        </div>
      )}

      {/* Add Visit Form */}
      {showAddForm && trials.length > 0 && (
        <form
          id="visit-form"
          onSubmit={handleSubmit}
          className="relative overflow-hidden bg-white border border-stone-200 rounded p-5 shadow-xs transition-all"
        >
          <div className="absolute top-0 left-0 right-0 h-1 bg-green-700" />

          <h3 className="text-xs font-bold text-stone-900 uppercase tracking-wider mb-4 flex items-center gap-1.5 mt-1">
            <CalendarIcon className="w-4 h-4 text-green-700" />
            Agendar Nova Visita Técnica Sincronizada
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Vinculação do Teste (Produtor) */}
            <div className="col-span-1 md:col-span-1">
              <label htmlFor="field-visit-trial" className="block text-[11px] font-bold text-stone-600 uppercase tracking-wider mb-1">
                Selecione o Produtor / Teste *
              </label>
              <select
                id="field-visit-trial"
                required
                value={selectedTrialId}
                onChange={(e) => setSelectedTrialId(e.target.value)}
                className="w-full bg-stone-50 border border-stone-200 text-stone-800 text-xs rounded focus:ring-1 focus:ring-stone-400 focus:border-stone-400 p-2 outline-none transition font-sans"
              >
                <option value="">-- Escolha um Produtor Rural --</option>
                {trials.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.producer} | {t.crop} — {t.farmName} ({t.status || 'Implantado'})
                  </option>
                ))}
              </select>
            </div>

            {/* Sincronização Automática dos Dados (Visual) */}
            <div className="col-span-1 md:col-span-2 grid grid-cols-3 gap-4 bg-stone-50 p-3 rounded border border-stone-200">
              <div>
                <p className="text-[9px] uppercase font-bold tracking-wider text-stone-450 font-mono">Produto</p>
                <p className="text-xs font-bold text-stone-800 mt-0.5 truncate">
                  {activeTrial ? activeTrial.product : <span className="text-stone-455 italic font-normal">Selecione o teste</span>}
                </p>
              </div>
              <div>
                <p className="text-[9px] uppercase font-bold tracking-wider text-stone-450 font-mono">Cultura</p>
                <p className="text-xs font-bold text-stone-800 mt-0.5">
                  {activeTrial ? activeTrial.crop : <span className="text-stone-455 italic font-normal">Selecione o teste</span>}
                </p>
              </div>
              <div>
                <p className="text-[9px] uppercase font-bold tracking-wider text-stone-450 font-mono">Safra & Status</p>
                <p className="text-xs font-bold text-stone-800 mt-0.5">
                  {activeTrial ? `${activeTrial.safra || '25/26'} (${activeTrial.status || 'Implantado'})` : <span className="text-stone-455 italic font-normal">Selecione o teste</span>}
                </p>
              </div>
            </div>

            {/* Data da Visita */}
            <div>
              <label htmlFor="field-visit-date" className="block text-[11px] font-bold text-stone-600 uppercase tracking-wider mb-1">
                Data Agendada da Visita *
              </label>
              <input
                type="date"
                id="field-visit-date"
                required
                value={visitDate}
                onChange={(e) => setVisitDate(e.target.value)}
                className="w-full bg-stone-50 border border-stone-200 text-stone-800 text-xs rounded focus:ring-1 focus:ring-stone-400 focus:border-stone-400 p-1.5 outline-none transition font-mono"
              />
            </div>

            {/* Status da Visita */}
            <div>
              <label htmlFor="field-visit-status" className="block text-[11px] font-bold text-stone-600 uppercase tracking-wider mb-1">
                Status da Visita *
              </label>
              <select
                id="field-visit-status"
                value={status}
                onChange={(e) => setStatus(e.target.value as VisitStatus)}
                className="w-full bg-stone-50 border border-stone-200 text-stone-800 text-xs rounded focus:ring-1 focus:ring-stone-400 focus:border-stone-400 p-2 outline-none transition font-sans"
              >
                <option value="pendente">Pendente / Agendada</option>
                <option value="realizada">Realizada</option>
              </select>
            </div>

            {/* Relatório Rápido DAS & DAA */}
            <div className="grid grid-cols-2 gap-4 bg-green-50/40 p-3 rounded border border-green-150">
              <div>
                <p className="text-[9px] uppercase font-bold tracking-wider text-green-700">DAS Automático</p>
                <p className="text-sm font-bold text-green-900 mt-0.5 font-mono">
                  {selectedTrialId && calculatedDas !== null ? (
                    <span>{calculatedDas} <span className="text-[9px] font-bold">dias</span></span>
                  ) : (
                    <span className="text-stone-400 text-xs font-normal">-</span>
                  )}
                </p>
                {activeTrial && (
                  <p className="text-[9px] text-green-650 font-mono mt-0.5">
                    Plantio: {formatDateBR(activeTrial.sowingDate)}
                  </p>
                )}
              </div>
              <div>
                <p className="text-[9px] uppercase font-bold tracking-wider text-green-700">DAA Automático</p>
                <p className="text-sm font-bold text-green-900 mt-0.5 font-mono">
                  {selectedTrialId && calculatedDaa !== null ? (
                    <span>{calculatedDaa} <span className="text-[9px] font-bold">dias</span></span>
                  ) : (
                    <span className="text-stone-400 text-xs font-normal">-</span>
                  )}
                </p>
                {activeTrial && (
                  <p className="text-[9px] text-green-655 font-mono mt-0.5">
                    Aplicação: {formatDateBR(activeTrial.applicationDate) || 'Não realizada'}
                  </p>
                )}
              </div>
            </div>

            {/* Observações / Notas Técnico */}
            <div className="col-span-1 md:col-span-3">
              <label htmlFor="field-visit-notes" className="block text-[11px] font-bold text-stone-600 uppercase tracking-wider mb-1">
                Relato da Visita (Ocorrências, Sanidade, Observações de Campo)
              </label>
              <textarea
                id="field-visit-notes"
                placeholder="Descreva o que foi observado em campo durante a vistoria..."
                rows={3}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full bg-stone-50 border border-stone-200 text-stone-850 placeholder:text-stone-400 text-xs rounded focus:ring-1 focus:ring-stone-400 focus:border-stone-400 p-2 outline-none transition font-sans"
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-2.5 mt-5 pt-4 border-t border-stone-150">
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="px-4 py-2 text-xs font-bold text-stone-500 hover:text-stone-700 bg-transparent hover:bg-stone-50 border border-transparent rounded transition uppercase"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-bold text-white bg-green-700 hover:bg-green-800 rounded shadow-xs transition uppercase"
            >
              Salvar Visita técnica
            </button>
          </div>
        </form>
      )}

      {/* RENDER VIEW MODE */}
      {viewMode === 'weekly' ? (
        /* CRONOGRAMA SEMANAL (WEEKLY VISIT SCHEDULE LAYOUT) */
        <div className="bg-white border border-stone-200 rounded p-5 shadow-xs space-y-6">
          
          {/* Weekly Header Navigator */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-stone-100 pb-4">
            <div className="space-y-1">
              <span className="text-[10px] uppercase font-bold text-green-750 tracking-wider font-mono flex items-center gap-1.5">
                <Route className="w-3.5 h-3.5" /> Roteiro de Vistorias Semanais
              </span>
              <h3 className="text-sm font-extrabold text-stone-900 uppercase">
                Semana de {formatDateBR(startOfWeek.toISOString().split('T')[0])} a {formatDateBR(endOfWeek.toISOString().split('T')[0])}
              </h3>
            </div>
            
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handlePrevWeek}
                className="px-3 py-1.5 text-xs font-bold text-stone-600 bg-stone-100 hover:bg-stone-200 border border-stone-250 rounded flex items-center gap-1 cursor-pointer transition"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>Semana Anterior</span>
              </button>
              
              <button
                type="button"
                onClick={handleSetToday}
                className="px-3 py-1.5 text-xs font-bold text-stone-800 bg-stone-100 hover:bg-stone-200 border border-stone-250 rounded cursor-pointer transition"
              >
                Hoje
              </button>

              <button
                type="button"
                onClick={handleNextWeek}
                className="px-3 py-1.5 text-xs font-bold text-stone-600 bg-stone-100 hover:bg-stone-200 border border-stone-250 rounded flex items-center gap-1 cursor-pointer transition"
              >
                <span>Próxima Semana</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Weekly Columns Grid */}
          <div className="grid grid-cols-1 md:grid-cols-7 gap-3">
            {weeklyDays.map((dayObj) => {
              const dayVisits = getVisitsForDate(dayObj.dateString);
              const isToday = dayObj.dateString === getTodayDateString();

              return (
                <div 
                  key={dayObj.dateString} 
                  className={`min-h-[250px] border rounded flex flex-col justify-between transition-all p-3 ${
                    isToday 
                      ? 'border-green-600 bg-green-50/5 ring-1 ring-green-600' 
                      : 'border-stone-200 bg-stone-50/20 hover:border-stone-300'
                  }`}
                >
                  {/* Day Title Header */}
                  <div>
                    <div className="flex items-center justify-between border-b border-stone-100 pb-2 mb-3">
                      <span className="text-[11px] font-black text-stone-800 tracking-wider">
                        {dayObj.dayLabel}
                      </span>
                      <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded ${
                        isToday 
                          ? 'bg-green-700 text-white font-bold' 
                          : 'bg-stone-100 text-stone-500 font-semibold'
                      }`}>
                        {dayObj.date.getDate()}
                      </span>
                    </div>

                    {/* Visits for this day */}
                    {dayVisits.length === 0 ? (
                      <div className="text-center py-8 text-stone-400 flex flex-col items-center justify-center space-y-1">
                        <CheckCircle className="w-4 h-4 text-stone-300" />
                        <span className="text-[9px] uppercase tracking-wider font-semibold">Livre</span>
                      </div>
                    ) : (
                      <div className="space-y-2.5">
                        {dayVisits.map((v) => {
                          const associatedTrial = trials.find(t => t.id === v.trialId);
                          return (
                            <div 
                              key={v.id} 
                              className={`p-2 rounded border text-[11px] space-y-1.5 relative group/card ${
                                v.status === 'realizada'
                                  ? 'bg-emerald-50/30 border-green-200 text-green-950'
                                  : 'bg-white border-stone-200 text-stone-900 shadow-3xs'
                              }`}
                            >
                              <div className="font-bold line-clamp-2 truncate" title={v.producerName}>
                                {v.producerName}
                              </div>
                              
                              <div className="text-[9.5px] text-stone-500 space-y-0.5">
                                <p className="truncate font-semibold text-stone-700">{v.crop} | {v.productUsed}</p>
                                {associatedTrial && (
                                  <p className="text-[8px] uppercase tracking-wide text-stone-400 truncate">{associatedTrial.farmName}</p>
                                )}
                              </div>

                              <div className="flex items-center justify-between text-[9px] font-mono pt-1 border-t border-stone-100">
                                <span className="text-green-800 font-bold">DAS: {v.das ?? 'N/A'}</span>
                                <span className={`px-1 rounded uppercase font-bold text-[7.5px] ${
                                  v.status === 'realizada' ? 'bg-green-100 text-green-800' : 'bg-amber-100 text-amber-800'
                                }`}>
                                  {v.status === 'realizada' ? 'OK' : 'PEND'}
                                </span>
                              </div>

                              {/* Hover actions */}
                              <div className="pt-1.5 flex items-center justify-end gap-1.5">
                                {v.status === 'pendente' ? (
                                  <button
                                    onClick={() => onUpdateVisitStatus(v.id, 'realizada')}
                                    title="Marcar como realizada"
                                    className="p-0.5 text-green-700 hover:text-white hover:bg-green-700 border border-green-200 rounded cursor-pointer transition text-[9px] px-1 font-bold"
                                  >
                                    OK
                                  </button>
                                ) : (
                                  <button
                                    onClick={() => onUpdateVisitStatus(v.id, 'pendente')}
                                    title="Marcar como pendente"
                                    className="p-0.5 text-stone-500 hover:text-white hover:bg-stone-500 border border-stone-200 rounded cursor-pointer transition text-[9px] px-1 font-bold"
                                  >
                                    Voltar
                                  </button>
                                )}
                                <button
                                  onClick={() => {
                                    if (confirm('Deseja excluir esta visita?')) {
                                      onDeleteVisit(v.id);
                                    }
                                  }}
                                  className="p-0.5 text-stone-400 hover:text-red-600 rounded cursor-pointer transition"
                                >
                                  <Trash2 className="w-3 h-3" />
                                </button>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>

                  {/* Column Footer: Quick add for this date */}
                  <div className="pt-3 border-t border-stone-100/60 mt-3 text-center">
                    <button
                      onClick={() => {
                        setVisitDate(dayObj.dateString);
                        setShowAddForm(true);
                        // focus form or select
                        const formElem = document.getElementById('visit-form');
                        if (formElem) formElem.scrollIntoView({ behavior: 'smooth' });
                      }}
                      className="text-[9.5px] font-bold uppercase tracking-wider text-green-700 hover:text-green-800 flex items-center justify-center gap-0.5 mx-auto cursor-pointer"
                    >
                      <Plus className="w-3 h-3" />
                      <span>Agendar</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="bg-stone-50 p-3.5 rounded border border-stone-200 flex flex-col sm:flex-row sm:items-center sm:justify-between text-xs text-stone-650 gap-2 leading-relaxed">
            <span className="font-semibold text-stone-750">💡 Visão Semanal Unificada</span>
            <span>
              Acompanhe seu roteiro dia-a-dia para otimizar os trajetos de campo. Para reagendar, basta excluir e criar uma visita no dia desejado ou utilizar o botão "Agendar".
            </span>
          </div>
        </div>
      ) : (
        /* CALENDÁRIO MENSAL & LISTA GERAL (ORIGINAL LAYOUT) */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Interactive Month Calendar (5 cols) */}
          <div className="lg:col-span-5 bg-white border border-stone-200 rounded p-5 shadow-xs flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold text-stone-900 text-xs uppercase tracking-wider flex items-center gap-1.5">
                  <CalendarIcon className="w-4 h-4 text-stone-500" />
                  <span>Calendário Técnico</span>
                </h3>
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={handlePrevMonth}
                    className="p-1 rounded hover:bg-stone-100 text-stone-600 transition cursor-pointer border border-transparent"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <span className="text-xs font-bold text-stone-800 min-w-[100px] text-center uppercase tracking-wide">
                    {monthNames[month]} {year}
                  </span>
                  <button
                    type="button"
                    onClick={handleNextMonth}
                    className="p-1 rounded hover:bg-stone-100 text-stone-600 transition cursor-pointer border border-transparent"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Grid headers */}
              <div className="grid grid-cols-7 gap-1 text-center mb-1">
                {weekdaysHeader.map((wd) => (
                  <span key={wd} className="text-[9px] font-bold text-stone-400 py-1 font-mono tracking-wider">
                    {wd}
                  </span>
                ))}
              </div>

              {/* Grid days */}
              <div className="grid grid-cols-7 gap-1 text-center">
                {calendarDays.map((calDay, idx) => {
                  const { day, dateString } = calDay;
                  if (day === null || !dateString) {
                    return <div key={`empty-${idx}`} className="aspect-square bg-stone-50 rounded" />;
                  }

                  const dayVisits = getVisitsForDate(dateString);
                  const hasVisits = dayVisits.length > 0;
                  const onlyPending = hasVisits && dayVisits.every(v => v.status === 'pendente');
                  const onlyRealized = hasVisits && dayVisits.every(v => v.status === 'realizada');

                  const isSelected = selectedCalendarDate === dateString;

                  let visitStatusColors = '';
                  if (hasVisits) {
                    if (onlyRealized) visitStatusColors = 'bg-emerald-50 text-emerald-800 border-emerald-300 font-bold';
                    else if (onlyPending) visitStatusColors = 'bg-amber-50 text-amber-800 border-amber-300 font-bold';
                    else visitStatusColors = 'bg-indigo-50 text-indigo-800 border-indigo-300 font-bold';
                  } else {
                    visitStatusColors = 'bg-transparent text-stone-700 border-transparent hover:bg-stone-50';
                  }

                  return (
                    <button
                      key={`day-${day}`}
                      type="button"
                      onClick={() => {
                        if (isSelected) {
                          setSelectedCalendarDate(null);
                        } else {
                          setSelectedCalendarDate(dateString);
                        }
                      }}
                      className={`aspect-square relative flex flex-col items-center justify-center rounded text-xs border transition cursor-pointer ${visitStatusColors} ${
                        isSelected ? 'ring-2 ring-stone-900 ring-offset-1 border-stone-900 font-bold' : ''
                      }`}
                    >
                      <span>{day}</span>
                      {hasVisits && (
                        <span className="absolute bottom-1 flex gap-0.5 justify-center">
                          {dayVisits.map((v) => (
                            <span
                              key={v.id}
                              className={`w-1 h-1 rounded-full ${
                                v.status === 'realizada' ? 'bg-emerald-500' : 'bg-amber-500'
                              }`}
                            />
                          ))}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Calendar Legend */}
            <div className="mt-5 pt-3 border-t border-stone-200 flex flex-wrap gap-x-4 gap-y-1.5 text-[9px] uppercase font-bold tracking-wider text-stone-500 justify-center">
              <span className="flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" /> Realizada
              </span>
              <span className="flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-500" /> Pendente
              </span>
              <span className="flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-indigo-500" /> Várias vistorias
              </span>
            </div>
          </div>

          {/* List of Scheduled Visits (7 cols) */}
          <div className="lg:col-span-7 space-y-4">
            <div className="bg-white border border-stone-200 rounded p-4 shadow-xs">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-4">
                <div>
                  <h3 className="font-bold text-stone-800 text-xs uppercase tracking-wider">
                    {selectedCalendarDate ? (
                      <span>Visitas para o dia: <strong className="text-green-800">{formatDateBR(selectedCalendarDate)}</strong></span>
                    ) : (
                      <span>Lista Geral de Visitas</span>
                    )}
                  </h3>
                  <p className="text-[11px] text-stone-500 mt-0.5">
                    {selectedCalendarDate 
                      ? 'Mostrando apenas visitas agendadas para esta data específica.' 
                      : 'Acompanhe as vistorias planejadas e efetuadas.'}
                  </p>
                </div>

                {/* Reset selected calendar date or toggle filter filter */}
                <div className="flex items-center gap-2">
                  {selectedCalendarDate && (
                    <button
                      type="button"
                      onClick={() => setSelectedCalendarDate(null)}
                      className="px-2 py-1 text-[10px] font-bold text-stone-750 bg-stone-100 hover:bg-stone-200 border border-stone-300 rounded cursor-pointer uppercase tracking-wider"
                    >
                      Ver Todas
                    </button>
                  )}
                  {!selectedCalendarDate && (
                    <div className="flex bg-stone-100 p-0.5 rounded border border-stone-200">
                      <button
                        type="button"
                        onClick={() => setListStatusFilter('all')}
                        className={`px-2 py-1 text-[9px] uppercase tracking-wider font-bold rounded-sm transition ${
                          listStatusFilter === 'all' ? 'bg-green-700 text-white shadow-3xs' : 'text-stone-500'
                        }`}
                      >
                        Todas
                      </button>
                      <button
                        type="button"
                        onClick={() => setListStatusFilter('pendente')}
                        className={`px-2 py-1 text-[9px] uppercase tracking-wider font-bold rounded-sm transition ${
                          listStatusFilter === 'pendente' ? 'bg-amber-100 text-amber-800' : 'text-stone-500'
                        }`}
                      >
                        Pendentes
                      </button>
                      <button
                        type="button"
                        onClick={() => setListStatusFilter('realizada')}
                        className={`px-2 py-1 text-[9px] uppercase tracking-wider font-bold rounded-sm transition ${
                          listStatusFilter === 'realizada' ? 'bg-emerald-100 text-emerald-800' : 'text-stone-500'
                        }`}
                      >
                        Realizadas
                      </button>
                    </div>
                  )}
                </div>
              </div>

              {/* Actual list of visits */}
              {(() => {
                const baseList = selectedCalendarDate 
                  ? visits.filter(v => v.visitDate === selectedCalendarDate)
                  : filteredVisits;

                const sortedList = [...baseList].sort((a, b) => {
                  return new Date(b.visitDate).getTime() - new Date(a.visitDate).getTime();
                });

                if (sortedList.length === 0) {
                  return (
                    <div className="text-center py-10 px-4 bg-stone-50 rounded border border-stone-200">
                      <Info className="w-6 h-6 text-stone-400 mx-auto mb-2" />
                      <p className="text-xs font-bold uppercase tracking-wider text-stone-700">Nenhuma visita nesta seleção</p>
                      <p className="text-[10px] text-stone-500 mt-1">
                        {selectedCalendarDate 
                          ? 'Você pode registrar uma visita para este dia clicando em "Agendar Visita" acima.' 
                          : 'Utilize os filtros acima ou lance uma visita para povoar o cronograma.'}
                      </p>
                    </div>
                  );
                }

                return (
                  <div id="visits-list-container" className="space-y-3 max-h-[460px] overflow-y-auto pr-1">
                    {sortedList.map((visit) => {
                      const linkedTrial = trials.find(t => t.id === visit.trialId);

                      return (
                        <div
                          key={visit.id}
                          className={`group p-4 rounded border transition-all hover:bg-stone-50 flex flex-col sm:flex-row sm:items-start justify-between gap-4 ${
                            visit.status === 'realizada'
                              ? 'bg-emerald-50/10 border-green-200'
                              : 'bg-white border-stone-200'
                          }`}
                        >
                          <div className="space-y-1">
                            <div className="flex flex-wrap items-center gap-2">
                              <h4 id="visit-item-title" className="text-xs font-bold text-stone-900 group-hover:text-green-800 transition">
                                {visit.producerName}
                              </h4>
                              <span className="text-[9px] uppercase tracking-wider font-bold bg-stone-100 text-stone-600 px-1.5 py-0.5 rounded border border-stone-200 shrink-0">
                                {visit.crop}
                              </span>
                              {linkedTrial && (linkedTrial.productTche || linkedTrial.productStandard) ? (
                                <span className="text-[10px] text-green-800 font-semibold italic bg-green-50 px-1.5 py-0.5 rounded border border-green-150 font-sans">
                                  {linkedTrial.productTche || 'Nutrição Tchê'} vs {linkedTrial.productStandard || 'Tratamento Padrão'}
                                </span>
                              ) : (
                                <span className="text-[10px] text-stone-500 font-semibold italic">
                                  ({visit.productUsed})
                                </span>
                              )}
                            </div>

                            {linkedTrial && (
                              <div className="flex items-center gap-1 text-[11px] text-stone-550 font-sans">
                                <MapPin className="w-3 h-3 text-stone-400" />
                                <span>{linkedTrial.farmName} — {linkedTrial.municipalityUf}</span>
                              </div>
                            )}

                            {/* Calculated parameters badge row */}
                            <div className="flex flex-wrap items-center gap-2 mt-1.5 font-mono">
                              <span className="inline-flex items-center gap-1 text-[10px] font-bold bg-green-50 text-green-800 px-2 py-0.5 rounded border border-green-250">
                                DAS: {visit.das ?? 'N/A'} <span className="text-[8px] font-bold uppercase tracking-wider">dias</span>
                              </span>
                              <span className="inline-flex items-center gap-1 text-[10px] font-bold bg-teal-50 text-teal-800 px-2 py-0.5 rounded border border-teal-250 font-mono">
                                DAA: {visit.daa ?? 'N/A'} <span className="text-[8px] font-bold uppercase tracking-wider">dias</span>
                              </span>
                              <span className="text-[10px] text-stone-500 font-semibold">
                                Visita: {formatDateBR(visit.visitDate)}
                              </span>
                            </div>

                            {/* Notes if loaded */}
                            {visit.notes && (
                              <p className="text-[11px] text-stone-655 bg-stone-50 p-2 rounded border border-stone-200 italic mt-2 line-clamp-2 select-text">
                                "{visit.notes}"
                              </p>
                            )}
                          </div>

                          {/* Status modifier buttons */}
                          <div className="flex sm:flex-col items-end justify-between sm:justify-start gap-2 shrink-0 border-t sm:border-0 pt-2 sm:pt-0 border-stone-100">
                            {visit.status === 'realizada' ? (
                              <div className="flex items-center gap-1 text-emerald-800 text-[10px] font-bold uppercase tracking-wider">
                                <CheckCircle className="w-4 h-4 text-emerald-600" />
                                <span>Realizada</span>
                              </div>
                            ) : (
                              <div className="flex items-center gap-1 text-amber-805 text-[10px] font-bold uppercase tracking-wider">
                                <Clock className="w-4 h-4 text-amber-550" />
                                <span>Pendente</span>
                              </div>
                            )}

                            <div className="flex items-center gap-1 mt-1.5">
                              {visit.status === 'pendente' ? (
                                <button
                                  type="button"
                                  onClick={() => onUpdateVisitStatus(visit.id, 'realizada')}
                                  title="Marcar como realizada"
                                  className="p-1 text-green-700 hover:text-white hover:bg-green-700 border border-green-300 rounded cursor-pointer transition"
                                >
                                  <Check className="w-3 h-3" />
                                </button>
                              ) : (
                                <button
                                  type="button"
                                  onClick={() => onUpdateVisitStatus(visit.id, 'pendente')}
                                  title="Marcar como pendente"
                                  className="p-1 text-stone-500 hover:text-white hover:bg-stone-500 border border-stone-300 rounded cursor-pointer transition"
                                >
                                  <Clock className="w-3 h-3" />
                                </button>
                              )}
                              <button
                                type="button"
                                onClick={() => {
                                  if (confirm('Tem certeza de que deseja excluir este agendamento de visita?')) {
                                    onDeleteVisit(visit.id);
                                  }
                                }}
                                title="Excluir visita"
                                className="p-1 text-stone-400 hover:text-red-600 border border-stone-200 hover:border-red-200 hover:bg-red-50 rounded cursor-pointer transition"
                              >
                                <Trash2 className="w-3 h-3" />
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                );
              })()}
            </div>
          </div>

        </div>
      )}
    </div>
  );
}
