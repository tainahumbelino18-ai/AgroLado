import React, { useState } from 'react';
import { Trial, Visit } from '../types';
import { formatDateBR } from '../utils';
import { 
  FileSearch, 
  User, 
  ShoppingBag, 
  Calendar, 
  MapPin, 
  CornerDownRight, 
  FileText, 
  Printer, 
  Layers,
  Sparkles,
  Award
} from 'lucide-react';

interface RelatoriosProps {
  visits: Visit[];
  trials: Trial[];
}

export function Relatorios({ visits, trials }: RelatoriosProps) {
  // Unique producers and unique products from registered trials & visits to feed the dropdowns
  const producersList = Array.from(
    new Set([
      ...trials.map(t => t.producer),
      ...visits.map(v => v.producerName)
    ])
  ).sort();

  const productsList = Array.from(
    new Set([
      ...trials.map(t => t.product),
      ...visits.map(v => v.productUsed)
    ])
  ).sort();

  // Filters State
  const [selectedProducer, setSelectedProducer] = useState<string>('');
  const [selectedProduct, setSelectedProduct] = useState<string>('');

  // Filtering visits
  const filteredVisits = visits.filter(v => {
    const matchProducer = !selectedProducer || v.producerName === selectedProducer;
    const matchProduct = !selectedProduct || v.productUsed === selectedProduct;
    return matchProducer && matchProduct;
  });

  // Sort chronological
  const sortedVisits = [...filteredVisits].sort((a, b) => {
    return new Date(a.visitDate).getTime() - new Date(b.visitDate).getTime();
  });

  // Get matching trial info for complementary header details (like municipality, farm name)
  const matchingTrial = trials.find(t => {
    if (selectedProducer) {
      return t.producer === selectedProducer && (!selectedProduct || t.product === selectedProduct);
    }
    return false;
  });

  // Stats calculation for the selection
  const totalVisits = sortedVisits.length;
  const realizedVisits = sortedVisits.filter(v => v.status === 'realizada').length;
  const pendingVisits = sortedVisits.filter(v => v.status === 'pendente').length;

  const handlePrint = () => {
    window.print();
  };

  const clearFilters = () => {
    setSelectedProducer('');
    setSelectedProduct('');
  };

  return (
    <div className="space-y-6">
      {/* Upper header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 id="reports-header" className="text-lg font-bold tracking-tight text-stone-900 flex items-center gap-2">
            <FileSearch className="w-5 h-5 text-green-700" />
            Relatórios Consolidados por Produtor / Tratamento
          </h2>
          <p className="text-xs text-stone-500">
            Filtre e audite todas as vistorias de campo efetuadas para avaliar o histórico de campo de forma clara.
          </p>
        </div>

        {totalVisits > 0 && (selectedProducer || selectedProduct) && (
          <button
            type="button"
            onClick={handlePrint}
            className="flex items-center justify-center gap-2 px-3 py-1.5 hover:bg-stone-105 text-stone-750 text-xs font-bold rounded border border-stone-300 transition cursor-pointer self-start sm:self-center uppercase tracking-wider"
          >
            <Printer className="w-3.5 h-3.5 text-stone-500" />
            Imprimir Relatório
          </button>
        )}
      </div>

      {/* Filter Selection Panel */}
      <div className="bg-white border border-stone-200 rounded p-5 shadow-xs">
        <h3 className="text-xs font-bold text-stone-450 uppercase tracking-wider mb-3">Filtros de Pesquisa</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Produtor Selection */}
          <div className="space-y-1">
            <label htmlFor="select-producer" className="block text-[11px] font-bold text-stone-600 uppercase tracking-wider">
              Produtor Rural
            </label>
            <div className="relative">
              <User className="absolute left-3 top-2.5 w-4 h-4 text-stone-400" />
              <select
                id="select-producer"
                value={selectedProducer}
                onChange={(e) => setSelectedProducer(e.target.value)}
                className="w-full bg-stone-50 border border-stone-200 text-stone-800 text-xs rounded pl-9 pr-4 py-2.5 outline-none focus:ring-1 focus:ring-stone-400 focus:border-stone-400 transition font-sans"
              >
                <option value="">-- Todos os Produtores Rurais --</option>
                {producersList.map(prod => (
                  <option key={prod} value={prod}>{prod}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Produto Selection */}
          <div className="space-y-1">
            <label htmlFor="select-product" className="block text-[11px] font-bold text-stone-600 uppercase tracking-wider">
              Produto / Tratamento Utilizado
            </label>
            <div className="relative">
              <ShoppingBag className="absolute left-3 top-2.5 w-4 h-4 text-stone-400" />
              <select
                id="select-product"
                value={selectedProduct}
                onChange={(e) => setSelectedProduct(e.target.value)}
                className="w-full bg-stone-50 border border-stone-200 text-stone-800 text-xs rounded pl-9 pr-4 py-2.5 outline-none focus:ring-1 focus:ring-stone-400 focus:border-stone-400 transition font-sans"
              >
                <option value="">-- Todos os Produtos / Tratamentos --</option>
                {productsList.map(prod => (
                  <option key={prod} value={prod}>{prod}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Clear buttons */}
        {(selectedProducer || selectedProduct) && (
          <div className="mt-4 pt-3 border-t border-stone-150 flex justify-end">
            <button
              type="button"
              onClick={clearFilters}
              className="text-xs font-bold text-green-800 hover:text-green-900 cursor-pointer uppercase tracking-wider"
            >
              Limpar Filtros Selecionados
            </button>
          </div>
        )}
      </div>

      {/* Main Report Section */}
      <div id="printable-report-area" className="bg-white border border-stone-200 rounded overflow-hidden shadow-xs p-6 space-y-6">
        
        {/* Report Header detail */}
        <div className="border-b border-stone-150 pb-5">
          <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
            <div>
              <span className="text-[9px] font-bold tracking-wider text-green-800 uppercase bg-green-50 px-2 py-1 rounded border border-green-150">
                Relatório Técnico Consolidado
              </span>
              <h3 className="text-base font-bold text-stone-900 mt-2.5">
                {selectedProducer ? `Dossiê: ${selectedProducer}` : 'Visão Geral das Vistorias de Área'}
              </h3>
              {matchingTrial && (
                <div className="mt-2 space-y-1 text-xs text-stone-500 font-sans">
                  <p className="flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-stone-400" />
                    <span>Propriedade: <strong>{matchingTrial.farmName}</strong> em <strong>{matchingTrial.municipalityUf}</strong></span>
                  </p>
                  <p className="flex items-center gap-1.5">
                    <Layers className="w-3.5 h-3.5 text-stone-400" />
                    <span>Cultura Avaliada: <span className="font-bold text-stone-700 bg-stone-100 px-1.5 py-0.5 rounded border border-stone-205 text-[10px] uppercase tracking-wide">{matchingTrial.crop}</span></span>
                  </p>
                </div>
              )}
            </div>

            {/* Quick stats grid for print/preview */}
            <div className="grid grid-cols-3 gap-3 md:gap-4 shrink-0 bg-stone-50 p-3 rounded border border-stone-200 font-mono">
              <div className="text-center px-1">
                <span className="block text-[9px] font-bold text-stone-450 uppercase tracking-wider">Total Visitas</span>
                <span id="report-total-visits" className="block text-base font-bold text-stone-850">{totalVisits}</span>
              </div>
              <div className="text-center px-1 border-l border-stone-200">
                <span className="block text-[9px] font-bold text-stone-450 uppercase tracking-wider">Realizadas</span>
                <span id="report-done-visits" className="block text-base font-bold text-green-800">{realizedVisits}</span>
              </div>
              <div className="text-center px-1 border-l border-stone-200">
                <span className="block text-[9px] font-bold text-stone-450 uppercase tracking-wider">Pendentes</span>
                <span id="report-pending-visits" className="block text-base font-bold text-amber-705">{pendingVisits}</span>
              </div>
            </div>
          </div>

          {/* Dates context widget is shown if matchingTrial is valid */}
          {matchingTrial && (
            <div className="mt-4 pt-4 border-t border-dotted border-stone-200 flex flex-wrap gap-x-6 gap-y-2 text-xs text-stone-600 font-sans">
              <div>
                <span className="text-stone-400">Tipo de Teste: </span>
                <span className="font-bold text-stone-700 uppercase bg-stone-100 border border-stone-250 px-1.5 py-0.5 rounded text-[9px]">
                  {matchingTrial.type}
                </span>
              </div>
              <div>
                <span className="text-stone-400">Data Semeadura: </span>
                <span className="font-bold text-stone-750 font-mono">{formatDateBR(matchingTrial.sowingDate)}</span>
              </div>
              <div>
                <span className="text-stone-400">Data de Aplicação: </span>
                <span className="font-bold text-stone-750 font-mono">{formatDateBR(matchingTrial.applicationDate)}</span>
              </div>
              {matchingTrial.harvestDate && (
                <div>
                  <span className="text-stone-400">Data Colheita Prevista: </span>
                  <span className="font-bold text-stone-750 font-mono">{formatDateBR(matchingTrial.harvestDate)}</span>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Timeline representation or detail list */}
        {totalVisits === 0 ? (
          <div className="text-center py-10">
            <FileText className="w-8 h-8 text-stone-300 mx-auto mb-3" />
            <p className="text-xs font-bold uppercase tracking-wider text-stone-700 font-sans">Nenhum registro de visita encontrado</p>
            <p className="text-xs text-stone-500 mt-1 max-w-sm mx-auto">
              Selecione outro filtro ou lance novas vistorias de visitas na aba "Cronograma" para alimentar os dados deste produtor.
            </p>
          </div>
        ) : (
          <div className="space-y-6">
            <h4 className="text-[10px] font-bold text-stone-450 uppercase tracking-wider">Histórico Cronológico de Acompanhamento</h4>
            
            {/* Timeline node list */}
            <div className="relative border-l-2 border-green-100 pl-6 space-y-6 ml-3">
              {sortedVisits.map((visit, index) => {
                const isRealized = visit.status === 'realizada';
                
                return (
                  <div key={visit.id} className="relative group font-sans">
                    {/* Timeline Node Bullet */}
                    <div className={`absolute -left-[31px] top-1 w-4 h-4 rounded-full border-2 transition ${
                      isRealized 
                        ? 'bg-green-700 border-white ring-2 ring-green-100' 
                        : 'bg-amber-500 border-white ring-2 ring-amber-100'
                    }`} />

                    {/* Timeline item header */}
                    <div className="bg-stone-50/70 hover:bg-stone-50 border border-stone-200/80 rounded p-4 transition-all">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold text-stone-800">
                              Visita #{index + 1} — {formatDateBR(visit.visitDate)}
                            </span>
                            <span className={`text-[9px] font-bold tracking-wide uppercase px-1.5 py-0.5 rounded border ${
                              isRealized 
                                ? 'bg-green-50 text-green-800 border-green-200' 
                                : 'bg-amber-50 text-amber-800 border-amber-200'
                            }`}>
                              {isRealized ? 'Realizada' : 'Pendente'}
                            </span>
                          </div>
                          
                          {/* Complementary context if filtered was general */}
                          {(!selectedProducer || !selectedProduct) && (
                            <p className="text-[11px] text-stone-500 mt-0.5">
                              Produtor Rural: <strong>{visit.producerName}</strong> | Produto: <span className="font-mono text-stone-600 font-semibold">{visit.productUsed}</span>
                            </p>
                          )}
                        </div>

                        {/* DAS & DAA automatic parameters */}
                        <div className="flex items-center gap-2 text-xs font-mono shrink-0">
                          {visit.das !== undefined && (
                            <div className="bg-green-50 text-green-850 border border-green-200 px-2.5 py-1 rounded text-[10px] font-medium flex items-center gap-1 font-mono">
                              <span>DAS:</span>
                              <strong className="text-green-950 font-bold">{visit.das ?? 'N/A'}</strong>
                              <span className="text-[9px] text-green-750 font-normal">dias</span>
                            </div>
                          )}
                          {visit.daa !== undefined && (
                            <div className="bg-teal-50 text-teal-850 border border-teal-200 px-2.5 py-1 rounded text-[10px] font-medium flex items-center gap-1 font-mono">
                              <span>DAA:</span>
                              <strong className="text-teal-950 font-bold">{visit.daa ?? 'N/A'}</strong>
                              <span className="text-[9px] text-teal-750 font-normal">dias</span>
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Technical Notes / Relatório descriptivo */}
                      {visit.notes ? (
                        <div className="mt-2.5 pt-2.5 border-t border-stone-200/60 text-[11px] text-stone-600 space-y-1 font-sans">
                          <span className="font-bold text-[9px] text-stone-400 uppercase block tracking-wider font-sans">Anotações Relevantes de Campo</span>
                          <p className="italic bg-white p-2.5 rounded border border-stone-200 leading-relaxed text-stone-800 select-text font-serif">
                            "{visit.notes}"
                          </p>
                        </div>
                      ) : (
                        <div className="mt-2 text-[10px] text-stone-450 italic">
                          Nenhuma observação técnica registrada para esta vistoria.
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Custom Technical recommendations recommendation based on historical growth */}
            {selectedProducer && totalVisits > 0 && (
              <div className="bg-green-50/20 border border-green-150 p-4 rounded flex items-start gap-3 mt-4 text-[11px] font-sans">
                <Award className="w-5 h-5 text-green-700 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <p className="font-bold text-green-900 uppercase tracking-wider">Análise de Progresso de Campo</p>
                  <p className="text-stone-650 leading-relaxed">
                    Sua área experimental registrada sob o produtor <strong className="text-stone-850">{selectedProducer}</strong> possui {totalVisits} visitas agendadas ao longo de seu período vegetativo. Monitore regularmente os DAS (Dias Após Semeadura) para aferir a passagem de estádios fenológicos e DAA (Dias Após Aplicação) para assegurar o residual de proteção efetivo do tratamento.
                  </p>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Styled Printable rules for Print view */}
      <style>{`
        @media print {
          body {
            background: white !important;
            color: black !important;
          }
          #printable-report-area {
            border: none !important;
            box-shadow: none !important;
            padding: 0 !important;
            margin: 0 !important;
          }
          /* Hide tabs header and form controls during prints */
          header, nav, button, select, label, .no-print {
            display: none !important;
          }
        }
      `}</style>
    </div>
  );
}
