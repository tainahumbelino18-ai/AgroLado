import React from 'react';
import { Trial, Visit } from '../types';
import { 
  Sprout, 
  Calendar, 
  FileText, 
  TrendingUp, 
  Activity, 
  CheckCircle2, 
  Clock, 
  MapPin, 
  Award, 
  Compass,
  ArrowUpRight,
  DollarSign,
  PieChart,
  Layers,
  ShoppingBag,
  TrendingDown
} from 'lucide-react';
import { formatDateBR } from '../utils';

interface DashboardStatsProps {
  trials: Trial[];
  visits: Visit[];
  onNavigate: (tab: string) => void;
}

export function DashboardStats({ trials, visits, onNavigate }: DashboardStatsProps) {
  // Counting logic
  const totalTrials = trials.length;
  const nutriTrialsCount = trials.filter(t => t.type === 'Nutri').length;
  const bioTrialsCount = trials.filter(t => t.type === 'Bio').length;
  const sementeTrialsCount = trials.filter(t => t.type === 'Semente').length;

  const totalVisits = visits.length;
  const realizedCount = visits.filter(v => v.status === 'realizada').length;
  const pendingCount = visits.filter(v => v.status === 'pendente').length;

  // Process Status Breakdown (Implantado, Em Andamento, Colhido, Entregue)
  const statusCounts = {
    'Implantado': trials.filter(t => (t.status || 'Implantado') === 'Implantado').length,
    'Em Andamento': trials.filter(t => t.status === 'Em Andamento').length,
    'Colhido': trials.filter(t => t.status === 'Colhido').length,
    'Entregue': trials.filter(t => t.status === 'Entregue').length,
  };

  // Safra breakdown
  const safraGroups: Record<string, { count: number; sales: number; convertedCount: number }> = {};
  trials.forEach(t => {
    const s = t.safra || '25/26';
    if (!safraGroups[s]) {
      safraGroups[s] = { count: 0, sales: 0, convertedCount: 0 };
    }
    safraGroups[s].count++;
    if (t.convertedToSale) {
      safraGroups[s].convertedCount++;
      safraGroups[s].sales += t.saleValue || 0;
    }
  });

  // Sales Conversion statistics
  const totalConverted = trials.filter(t => t.convertedToSale).length;
  const conversionRate = totalTrials > 0 ? Math.round((totalConverted / totalTrials) * 100) : 0;
  const totalSaleValue = trials.reduce((sum, t) => sum + (t.convertedToSale ? (t.saleValue || 0) : 0), 0);

  // Conversion rates and values by category
  const getCategoryStats = (cat: 'Nutri' | 'Bio' | 'Semente') => {
    const catTrials = trials.filter(t => t.type === cat);
    const total = catTrials.length;
    const converted = catTrials.filter(t => t.convertedToSale).length;
    const rate = total > 0 ? Math.round((converted / total) * 100) : 0;
    const value = catTrials.reduce((sum, t) => sum + (t.convertedToSale ? (t.saleValue || 0) : 0), 0);
    return { total, converted, rate, value };
  };

  const nutriStats = getCategoryStats('Nutri');
  const bioStats = getCategoryStats('Bio');
  const sementeStats = getCategoryStats('Semente');

  // Retrieve next 3 pending visits based on nearest future dates
  const sortedPendingVisits = [...visits]
    .filter(v => v.status === 'pendente')
    .sort((a, b) => new Date(a.visitDate).getTime() - new Date(b.visitDate).getTime())
    .slice(0, 3);

  // Retrieve last 3 done visits based on most recent dates
  const sortedRecentVisits = [...visits]
    .filter(v => v.status === 'realizada')
    .sort((a, b) => new Date(b.visitDate).getTime() - new Date(a.visitDate).getTime())
    .slice(0, 3);

  return (
    <div className="space-y-6">
      {/* Upper Welcome Header */}
      <div 
        style={{ backgroundColor: '#17630f', backgroundImage: 'none' }}
        className="border border-green-900 rounded p-6 text-white relative overflow-hidden shadow-sm"
      >
        <div 
          style={{ backgroundColor: '#0c5407' }}
          className="absolute right-0 top-0 w-64 h-64 rounded-full blur-2xl transform translate-x-12 -translate-y-12" 
        />
        <div className="absolute right-12 bottom-0 w-44 h-44 bg-green-500/10 rounded-full blur-xl" />

        <div className="relative z-10 max-w-2xl space-y-1.5">
          <span className="text-[9px] uppercase font-bold tracking-widest bg-green-600 text-green-50 px-2.5 py-1 rounded border border-green-500/30">
            Painel Central do Agrônomo
          </span>
          <h2 id="dashboard-header" className="text-xl md:text-2xl font-bold tracking-tight">
            Plataforma Lado a Lado Agrícola (LAL)
          </h2>
          <p className="text-xs md:text-sm text-green-100/90 leading-relaxed font-sans max-w-lg">
            Monitore seus testes de campo comerciais variando entre nutrição foliar, defensivos biológicos e novas sementes. Sincronize visitas com produtores e tenha controle de DAS, DAA e conversão comercial.
          </p>
        </div>
      </div>

      {/* PIPELINE DE ACOMPANHAMENTO (Process Status Breakdown) */}
      <div className="space-y-2">
        <h3 className="text-xs font-bold text-stone-500 uppercase tracking-wider flex items-center gap-1.5">
          <Layers className="w-4 h-4 text-green-700" />
          Fases e Status do Processo LAL
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {/* Implantado */}
          <div className="bg-amber-50/40 border border-amber-200/80 rounded p-3.5 flex flex-col justify-between shadow-3xs relative overflow-hidden">
            <div className="absolute top-0 left-0 bottom-0 w-1 bg-amber-500" />
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold text-amber-800 uppercase tracking-wider">1. Implantado</span>
              <Clock className="w-3.5 h-3.5 text-amber-500" />
            </div>
            <div className="mt-2.5">
              <span className="text-2xl font-extrabold text-stone-900 block">{statusCounts['Implantado']}</span>
              <span className="text-[9px] text-stone-500 block">Testes recém-semeados / instalados</span>
            </div>
          </div>

          {/* Em Andamento */}
          <div className="bg-blue-50/30 border border-blue-200/80 rounded p-3.5 flex flex-col justify-between shadow-3xs relative overflow-hidden">
            <div className="absolute top-0 left-0 bottom-0 w-1 bg-blue-500" />
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold text-blue-800 uppercase tracking-wider">2. Em Andamento</span>
              <Activity className="w-3.5 h-3.5 text-blue-500" />
            </div>
            <div className="mt-2.5">
              <span className="text-2xl font-extrabold text-stone-900 block">{statusCounts['Em Andamento']}</span>
              <span className="text-[9px] text-stone-500 block">Monitoramentos e visitas ativas</span>
            </div>
          </div>

          {/* Colhido */}
          <div className="bg-emerald-50/35 border border-emerald-200/80 rounded p-3.5 flex flex-col justify-between shadow-3xs relative overflow-hidden">
            <div className="absolute top-0 left-0 bottom-0 w-1 bg-emerald-500" />
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold text-emerald-800 uppercase tracking-wider">3. Colhido</span>
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
            </div>
            <div className="mt-2.5">
              <span className="text-2xl font-extrabold text-stone-900 block">{statusCounts['Colhido']}</span>
              <span className="text-[9px] text-stone-500 block">Dados de sacas/ha cadastrados</span>
            </div>
          </div>

          {/* Entregue */}
          <div className="bg-purple-50/30 border border-purple-200/80 rounded p-3.5 flex flex-col justify-between shadow-3xs relative overflow-hidden">
            <div className="absolute top-0 left-0 bottom-0 w-1 bg-purple-500" />
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold text-purple-800 uppercase tracking-wider">4. Entregue</span>
              <Award className="w-3.5 h-3.5 text-purple-500" />
            </div>
            <div className="mt-2.5">
              <span className="text-2xl font-extrabold text-stone-900 block">{statusCounts['Entregue']}</span>
              <span className="text-[9px] text-stone-500 block">Resultados levados ao produtor</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Stats Widgets Row */}
      <div className="space-y-2">
        <h3 className="text-xs font-bold text-stone-500 uppercase tracking-wider">Acompanhamento e Métricas</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          
          {/* Card total test fields */}
          <div className="bg-white border border-stone-200 p-5 rounded-lg shadow-xs flex items-center justify-between">
            <div className="space-y-1">
              <span className="block text-xs font-semibold text-stone-500">Total de Testes</span>
              <span className="block text-2xl font-extrabold text-stone-900">{totalTrials}</span>
              <div className="flex items-center gap-1 text-[8.5px] font-mono font-bold">
                <span className="bg-emerald-50 text-emerald-700 px-1 py-0.5 rounded border border-emerald-150">{nutriTrialsCount} N</span>
                <span className="bg-teal-50 text-teal-700 px-1 py-0.5 rounded border border-teal-150">{bioTrialsCount} B</span>
                <span className="bg-amber-50 text-amber-700 px-1 py-0.5 rounded border border-amber-150">{sementeTrialsCount} S</span>
              </div>
            </div>
            <div className="w-10 h-10 rounded bg-green-50 text-green-700 flex items-center justify-center border border-green-200">
              <Sprout className="w-5 h-5" />
            </div>
          </div>

          {/* Conversão em Vendas Card */}
          <div className="bg-white border border-stone-200 p-5 rounded-lg shadow-xs flex items-center justify-between">
            <div className="space-y-1">
              <span className="block text-xs font-semibold text-stone-500">Vendas Geradas</span>
              <span className="block text-xl font-extrabold text-emerald-800">
                R$ {totalSaleValue.toLocaleString('pt-BR', { minimumFractionDigits: 0 })}
              </span>
              <span className="block text-[10px] text-emerald-700 font-semibold">
                💰 {totalConverted} de {totalTrials} convertidos ({conversionRate}%)
              </span>
            </div>
            <div className="w-10 h-10 rounded bg-emerald-50 text-emerald-700 flex items-center justify-center border border-emerald-250">
              <DollarSign className="w-5 h-5" />
            </div>
          </div>

          {/* Card total scheduled visits */}
          <div className="bg-white border border-stone-200 p-5 rounded-lg shadow-xs flex items-center justify-between">
            <div className="space-y-1">
              <span className="block text-xs font-semibold text-stone-500">Agendamentos</span>
              <span className="block text-2xl font-extrabold text-stone-900">{totalVisits}</span>
              <span className="block text-[10px] text-stone-400">
                Total de vistorias agendadas
              </span>
            </div>
            <div className="w-10 h-10 rounded bg-stone-100 text-stone-700 flex items-center justify-center border border-stone-200">
              <Calendar className="w-4.5 h-4.5" />
            </div>
          </div>

          {/* Card Done ratio */}
          <div className="bg-white border border-stone-200 p-5 rounded-lg shadow-xs flex items-center justify-between">
            <div className="space-y-1">
              <span className="block text-xs font-semibold text-stone-500">Vistorias Realizadas</span>
              <span className="block text-2xl font-extrabold text-green-700">{realizedCount}</span>
              <span className="block text-[10px] text-green-600 font-semibold flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" /> {totalVisits > 0 ? Math.round((realizedCount / totalVisits) * 100) : 0}% concluído
              </span>
            </div>
            <div className="w-10 h-10 rounded bg-green-50 text-green-700 flex items-center justify-center border border-green-200">
              <CheckCircle2 className="w-4.5 h-4.5" />
            </div>
          </div>
        </div>
      </div>

      {/* CHARTS & ANALYTICS SECTION */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* CHART 1: Testes por Categoria */}
        <div className="bg-white border border-stone-200 rounded-lg p-5 shadow-xs flex flex-col justify-between">
          <div>
            <h3 className="font-bold text-stone-800 text-xs uppercase tracking-wider flex items-center gap-1.5 border-b border-stone-100 pb-2 mb-4">
              <PieChart className="w-4 h-4 text-green-700" />
              Testes por Categoria
            </h3>
            <p className="text-[11px] text-stone-500 mb-4">Quantidade total de testes instalados divididos por tipo tecnológico.</p>
            
            <div className="space-y-4">
              {/* Nutrição */}
              <div>
                <div className="flex items-center justify-between text-xs font-bold mb-1.5 text-stone-700">
                  <span className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-600 inline-block" />
                    Nutrição Foliar
                  </span>
                  <span>{nutriTrialsCount} ({totalTrials > 0 ? Math.round((nutriTrialsCount / totalTrials) * 100) : 0}%)</span>
                </div>
                <div className="w-full h-3 bg-stone-100 rounded-full overflow-hidden border border-stone-200/50">
                  <div 
                    style={{ width: `${totalTrials > 0 ? (nutriTrialsCount / totalTrials) * 100 : 0}%` }}
                    className="h-full bg-emerald-600 rounded-full transition-all"
                  />
                </div>
              </div>

              {/* Biológico */}
              <div>
                <div className="flex items-center justify-between text-xs font-bold mb-1.5 text-stone-700">
                  <span className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-teal-600 inline-block" />
                    Defensivos Biológicos
                  </span>
                  <span>{bioTrialsCount} ({totalTrials > 0 ? Math.round((bioTrialsCount / totalTrials) * 100) : 0}%)</span>
                </div>
                <div className="w-full h-3 bg-stone-100 rounded-full overflow-hidden border border-stone-200/50">
                  <div 
                    style={{ width: `${totalTrials > 0 ? (bioTrialsCount / totalTrials) * 100 : 0}%` }}
                    className="h-full bg-teal-600 rounded-full transition-all"
                  />
                </div>
              </div>

              {/* Semente */}
              <div>
                <div className="flex items-center justify-between text-xs font-bold mb-1.5 text-stone-700">
                  <span className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-600 inline-block" />
                    Sementes e Híbridos
                  </span>
                  <span>{sementeTrialsCount} ({totalTrials > 0 ? Math.round((sementeTrialsCount / totalTrials) * 100) : 0}%)</span>
                </div>
                <div className="w-full h-3 bg-stone-100 rounded-full overflow-hidden border border-stone-200/50">
                  <div 
                    style={{ width: `${totalTrials > 0 ? (sementeTrialsCount / totalTrials) * 100 : 0}%` }}
                    className="h-full bg-amber-600 rounded-full transition-all"
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="bg-stone-50 p-2.5 rounded border border-stone-200/70 mt-6 text-[10px] text-stone-500 font-mono text-center">
            {totalTrials} testes comerciais mapeados
          </div>
        </div>

        {/* CHART 2: Separação por Safra */}
        <div className="bg-white border border-stone-200 rounded-lg p-5 shadow-xs flex flex-col justify-between">
          <div>
            <h3 className="font-bold text-stone-800 text-xs uppercase tracking-wider flex items-center gap-1.5 border-b border-stone-100 pb-2 mb-4">
              <Layers className="w-4 h-4 text-green-750" />
              Testes Separados por Safra
            </h3>
            <p className="text-[11px] text-stone-500 mb-4 font-sans">Visualização e contagem de testes comerciais separados por safra produtiva.</p>

            {Object.keys(safraGroups).length === 0 ? (
              <p className="text-xs text-stone-400 italic text-center py-6">Nenhuma safra cadastrada nos testes.</p>
            ) : (
              <div className="space-y-4">
                {Object.entries(safraGroups).map(([safraKey, data]) => {
                  const pct = totalTrials > 0 ? Math.round((data.count / totalTrials) * 100) : 0;
                  return (
                    <div key={safraKey} className="border border-stone-150 p-3 rounded bg-stone-50/50 space-y-2">
                      <div className="flex items-center justify-between text-xs font-bold text-stone-800">
                        <span className="bg-green-100 text-green-800 px-2 py-0.5 rounded font-mono text-[10px]">
                          Safra {safraKey}
                        </span>
                        <span>{data.count} {data.count === 1 ? 'teste' : 'testes'} ({pct}%)</span>
                      </div>
                      <div className="w-full h-2 bg-stone-100 rounded-full overflow-hidden">
                        <div 
                          style={{ width: `${pct}%` }}
                          className="h-full bg-green-700 rounded-full"
                        />
                      </div>
                      <div className="flex justify-between items-center text-[9.5px] text-stone-500 pt-1">
                        <span>Conversões: <span className="font-bold text-emerald-800">{data.convertedCount}</span></span>
                        <span>Faturamento: <span className="font-bold text-stone-700">R$ {data.sales.toLocaleString('pt-BR', { minimumFractionDigits: 0 })}</span></span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
          
          <div className="text-[10px] text-stone-500 mt-4 leading-normal italic">
            * Altere a safra no formulário de cadastro para catalogar os testes.
          </div>
        </div>

        {/* CHART 3: Retorno Comercial e Conversão em Vendas */}
        <div className="bg-white border border-stone-200 rounded-lg p-5 shadow-xs flex flex-col justify-between">
          <div>
            <h3 className="font-bold text-stone-800 text-xs uppercase tracking-wider flex items-center gap-1.5 border-b border-stone-100 pb-2 mb-4">
              <ShoppingBag className="w-4 h-4 text-emerald-700" />
              Retorno Comercial e Conversão
            </h3>
            <p className="text-[11px] text-stone-500 mb-4 font-sans">
              Mapeamento de conversão comercial: testes colhidos que resultaram em vendas efetivas.
            </p>

            <div className="flex items-center gap-4 mb-4 bg-emerald-50/30 border border-emerald-150 p-3 rounded">
              {/* Circular Gauge via SVG */}
              <div className="relative w-14 h-14 shrink-0 flex items-center justify-center">
                <svg className="w-full h-full transform -rotate-90">
                  <circle
                    cx="28"
                    cy="28"
                    r="24"
                    stroke="#f5f5f4"
                    strokeWidth="4"
                    fill="transparent"
                  />
                  <svg>
                    <circle
                      cx="28"
                      cy="28"
                      r="24"
                      stroke="#10b981"
                      strokeWidth="4"
                      fill="transparent"
                      strokeDasharray="150.79"
                      strokeDashoffset={150.79 - (150.79 * conversionRate) / 100}
                      strokeLinecap="round"
                    />
                  </svg>
                </svg>
                <span className="absolute text-xs font-black text-emerald-800">{conversionRate}%</span>
              </div>
              <div>
                <span className="text-[10px] text-stone-400 font-bold block uppercase tracking-wide">Taxa Geral de Venda</span>
                <span className="text-sm font-extrabold text-stone-800">Alta Efetividade Comercial</span>
                <p className="text-[10px] text-stone-500">Nossos testes demonstram na prática os acréscimos produtivos.</p>
              </div>
            </div>

            {/* Category Conversion Metrics */}
            <div className="space-y-2.5 text-xs">
              <span className="text-[9px] uppercase font-bold text-stone-400 block tracking-wider">Conversão por Categoria</span>
              
              {/* Nutrição */}
              <div className="flex items-center justify-between py-1 border-b border-stone-100">
                <span className="text-stone-600 font-semibold">Nutrição Foliar:</span>
                <div className="text-right">
                  <span className="font-bold text-stone-800">{nutriStats.converted} de {nutriStats.total}</span>
                  <span className="bg-emerald-100 text-emerald-800 font-bold px-1 rounded ml-1.5 text-[9px]">{nutriStats.rate}%</span>
                </div>
              </div>

              {/* Biológico */}
              <div className="flex items-center justify-between py-1 border-b border-stone-100">
                <span className="text-stone-600 font-semibold">Defensivos Biológicos:</span>
                <div className="text-right">
                  <span className="font-bold text-stone-800">{bioStats.converted} de {bioStats.total}</span>
                  <span className="bg-emerald-100 text-emerald-800 font-bold px-1 rounded ml-1.5 text-[9px]">{bioStats.rate}%</span>
                </div>
              </div>

              {/* Semente */}
              <div className="flex items-center justify-between py-1 border-b border-stone-100">
                <span className="text-stone-600 font-semibold">Sementes:</span>
                <div className="text-right">
                  <span className="font-bold text-stone-800">{sementeStats.converted} de {sementeStats.total}</span>
                  <span className="bg-stone-200 text-stone-700 font-bold px-1 rounded ml-1.5 text-[9px]">{sementeStats.rate}%</span>
                </div>
              </div>
            </div>
          </div>

          <div className="text-[10px] text-emerald-800 bg-emerald-50 p-2 rounded border border-emerald-100 font-medium text-center mt-4">
            💸 Faturamento Total Influenciado: <span className="font-extrabold">R$ {totalSaleValue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
          </div>
        </div>

      </div>

      {/* Structured splits: Next actions & immediate vistorias lists */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Quick Menu Launcher (4 cols) */}
        <div className="lg:col-span-4 bg-white border border-stone-200 rounded-lg p-5 shadow-xs space-y-4 flex flex-col justify-between">
          <div className="space-y-4">
            <h3 className="font-bold text-stone-800 text-xs uppercase tracking-wider flex items-center gap-1.5 border-b border-stone-100 pb-2">
              <Compass className="w-4 h-4 text-green-650" />
              Atalhos Operacionais
            </h3>
            <p className="text-xs text-stone-650 font-sans leading-relaxed">
              Navegue rapidamente pelas abas de controle para iniciar o planejamento.
            </p>

            <div className="space-y-2">
              <button
                onClick={() => onNavigate('trials')}
                className="w-full text-left p-3 border border-stone-100 hover:border-green-300 hover:bg-green-50/20 rounded text-xs font-semibold text-stone-700 hover:text-green-800 transition flex items-center justify-between group cursor-pointer"
              >
                <span>1. Cadastrar Teste Lado a Lado</span>
                <ArrowUpRight className="w-3.5 h-3.5 opacity-40 group-hover:opacity-100 transition" />
              </button>
              <button
                onClick={() => onNavigate('cronograma')}
                className="w-full text-left p-3 border border-stone-100 hover:border-green-300 hover:bg-green-50/20 rounded text-xs font-semibold text-stone-700 hover:text-green-800 transition flex items-center justify-between group cursor-pointer"
              >
                <span>2. Cronograma de Visitas (DAS/DAA)</span>
                <ArrowUpRight className="w-3.5 h-3.5 opacity-40 group-hover:opacity-100 transition" />
              </button>
              <button
                onClick={() => onNavigate('reports')}
                className="w-full text-left p-3 border border-stone-100 hover:border-stone-300 hover:bg-stone-50 rounded text-xs font-semibold text-stone-700 hover:text-stone-850 transition flex items-center justify-between group cursor-pointer"
              >
                <span>3. Relatórios detalhados</span>
                <ArrowUpRight className="w-3.5 h-3.5 opacity-40 group-hover:opacity-100 transition" />
              </button>
            </div>
          </div>

          <div className="bg-stone-50 p-3.5 rounded border border-stone-200 text-[11px] text-stone-650 leading-relaxed font-sans space-y-1.5 mt-4">
            <span className="font-bold text-stone-700 flex items-center gap-1">
              <Award className="w-3.5 h-3.5 text-stone-600" />
              Como funciona o LAL:
            </span>
            <ul className="list-disc pl-3.5 space-y-1">
              <li>Cadastre o teste (sementes, nutrição ou biocontrole) definindo safra, filial, consultor e status.</li>
              <li>Acesse o Cronograma para criar visitas vinculadas e gerenciar visitas semanais.</li>
              <li>Acompanhe a taxa de conversão comercial para justificar o investimento no portfólio Tchê.</li>
            </ul>
          </div>
        </div>

        {/* Lists showing upcoming and done (8 cols) */}
        <div className="lg:col-span-8 bg-white border border-stone-200 rounded-lg p-5 shadow-xs space-y-5">
          
          {/* Upcoming visits */}
          <div>
            <h3 className="font-bold text-stone-800 text-xs uppercase tracking-wider flex items-center gap-1.5 border-b border-stone-100 pb-2 mb-3">
              <Clock className="w-4 h-4 text-amber-500" />
              Próximas Visitas Agendadas (Pendentes)
            </h3>

            {sortedPendingVisits.length === 0 ? (
              <p className="text-xs text-stone-400 italic py-2">Nenhuma visita pendente programada. Fique em dia!</p>
            ) : (
              <div className="space-y-2.5">
                {sortedPendingVisits.map(visit => (
                  <div key={visit.id} className="p-3 border border-stone-200 rounded flex items-center justify-between text-xs hover:border-stone-300 hover:bg-stone-50/50 transition">
                    <div>
                      <span className="font-semibold text-stone-800">{visit.producerName}</span>
                      <p className="text-[10px] text-stone-500 mt-0.5">
                        Cultura: {visit.crop} ({visit.productUsed}) — Visita {formatDateBR(visit.visitDate)}
                      </p>
                    </div>
                    <div className="text-right shrink-0">
                      <span className="bg-amber-100 text-amber-800 text-[9px] font-bold px-2 py-0.5 rounded uppercase">Pendente</span>
                      <span className="block text-[10px] font-mono text-stone-600 mt-1">DAS: {visit.das ?? 'N/A'}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Recent finished visits */}
          <div>
            <h3 className="font-bold text-stone-800 text-xs uppercase tracking-wider flex items-center gap-1.5 border-b border-stone-100 pb-2 mb-3">
              <CheckCircle2 className="w-4 h-4 text-green-700" />
              Últimas Visitas Realizadas (Arquivo)
            </h3>

            {sortedRecentVisits.length === 0 ? (
              <p className="text-xs text-stone-400 italic py-2">Nenhuma vistoria de campo concluída foi arquivada ainda.</p>
            ) : (
              <div className="space-y-2.5">
                {sortedRecentVisits.map(visit => (
                  <div key={visit.id} className="p-3 border border-green-200 bg-green-50/10 rounded flex items-center justify-between text-xs hover:border-green-350 transition">
                    <div>
                      <span className="font-semibold text-stone-800">{visit.producerName}</span>
                      <p className="text-[10px] text-stone-500 mt-0.5">
                        Cultura: {visit.crop} ({visit.productUsed}) — Concluído em {formatDateBR(visit.visitDate)}
                      </p>
                    </div>
                    <div className="text-right shrink-0">
                      <span className="bg-green-100 text-green-800 text-[9px] font-bold px-2 py-0.5 rounded uppercase">Realizada</span>
                      <span className="block text-[10px] font-mono text-green-700 mt-1 font-semibold">DAS: {visit.das ?? 'N/A'} | DAA: {visit.daa ?? 'N/A'}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

        </div>

      </div>
    </div>
  );
}
