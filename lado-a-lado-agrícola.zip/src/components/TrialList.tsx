import React, { useState } from 'react';
import { Trial, TrialType, TrialStatus, AdditionalProduct } from '../types';
import { formatDateBR, getTodayDateString } from '../utils';
import { Plus, Search, Trash2, Sprout, Filter, MapPin, Calendar, HelpCircle, FileSpreadsheet, Edit3 } from 'lucide-react';

interface TrialListProps {
  trials: Trial[];
  onAddTrial: (trial: Trial) => void;
  onDeleteTrial: (id: string) => void;
  onEditTrial?: (trial: Trial) => void;
}

export function TrialList({ trials, onAddTrial, onDeleteTrial, onEditTrial }: TrialListProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState<'All' | TrialType>('All');
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingTrialId, setEditingTrialId] = useState<string | null>(null);

  // Form Fields
  const [type, setType] = useState<TrialType>('Nutri');
  const [producer, setProducer] = useState('');
  const [product, setProduct] = useState('');
  const [productTche, setProductTche] = useState('');
  const [productStandard, setProductStandard] = useState('');
  const [crop, setCrop] = useState('');
  const [sowingDate, setSowingDate] = useState(getTodayDateString());
  const [applicationDate, setApplicationDate] = useState(''); // default empty (optional)
  const [harvestDate, setHarvestDate] = useState('');
  const [farmName, setFarmName] = useState('');
  const [municipalityUf, setMunicipalityUf] = useState('');
  const [notes, setNotes] = useState('');
  const [harvestedAreaTche, setHarvestedAreaTche] = useState('');
  const [bagsPerHaTche, setBagsPerHaTche] = useState('');
  const [harvestedAreaStandard, setHarvestedAreaStandard] = useState('');
  const [bagsPerHaStandard, setBagsPerHaStandard] = useState('');

  // Novos campos solicitados
  const [safra, setSafra] = useState('25/26');
  const [filial, setFilial] = useState('');
  const [consultor, setConsultor] = useState('');
  const [status, setStatus] = useState<TrialStatus>('Implantado');
  const [convertedToSale, setConvertedToSale] = useState(false);
  const [saleValue, setSaleValue] = useState('');

  // Estados adicionais para múltiplos produtos e autocomplete de produtor
  const [additionalProducts, setAdditionalProducts] = useState<AdditionalProduct[]>([]);
  const [customSafraMode, setCustomSafraMode] = useState(false);
  const [autoFilledNotice, setAutoFilledNotice] = useState(false);

  const handleProducerChange = (val: string) => {
    setProducer(val);
    
    // Procura por produtor idêntico cadastrado anteriormente para auto-preecher dados de localidade
    const match = trials.find(t => t.producer.trim().toLowerCase() === val.trim().toLowerCase());
    if (match) {
      setFarmName(match.farmName || '');
      setMunicipalityUf(match.municipalityUf || '');
      setFilial(match.filial || '');
      setConsultor(match.consultor || '');
      setAutoFilledNotice(true);
    } else {
      setAutoFilledNotice(false);
    }
  };

  const resetForm = () => {
    setType('Nutri');
    setProducer('');
    setProduct('');
    setProductTche('');
    setProductStandard('');
    setCrop('');
    setSowingDate(getTodayDateString());
    setApplicationDate('');
    setHarvestDate('');
    setFarmName('');
    setMunicipalityUf('');
    setNotes('');
    setHarvestedAreaTche('');
    setBagsPerHaTche('');
    setHarvestedAreaStandard('');
    setBagsPerHaStandard('');
    
    // reset novos campos
    setSafra('25/26');
    setCustomSafraMode(false);
    setFilial('');
    setConsultor('');
    setStatus('Implantado');
    setConvertedToSale(false);
    setSaleValue('');
    setAdditionalProducts([]);
    setAutoFilledNotice(false);
    setEditingTrialId(null);
  };

  const handleEditInit = (trial: Trial) => {
    setEditingTrialId(trial.id);
    setType(trial.type);
    setProducer(trial.producer);
    setProduct(trial.product);
    setProductTche(trial.productTche || '');
    setProductStandard(trial.productStandard || '');
    setCrop(trial.crop);
    setSowingDate(trial.sowingDate);
    setApplicationDate(trial.applicationDate || '');
    setHarvestDate(trial.harvestDate || '');
    setFarmName(trial.farmName);
    setMunicipalityUf(trial.municipalityUf);
    setNotes(trial.notes || '');
    setHarvestedAreaTche(trial.harvestedAreaTche !== undefined ? String(trial.harvestedAreaTche) : '');
    setBagsPerHaTche(trial.bagsPerHaTche !== undefined ? String(trial.bagsPerHaTche) : '');
    setHarvestedAreaStandard(trial.harvestedAreaStandard !== undefined ? String(trial.harvestedAreaStandard) : '');
    setBagsPerHaStandard(trial.bagsPerHaStandard !== undefined ? String(trial.bagsPerHaStandard) : '');
    
    // load novos campos com fallbacks para dados antigos
    setSafra(trial.safra || '25/26');
    const standardSafras = ['25/26', '24/25', '23/24', '26/27'];
    if (trial.safra && !standardSafras.includes(trial.safra)) {
      setCustomSafraMode(true);
    } else {
      setCustomSafraMode(false);
    }
    setFilial(trial.filial || '');
    setConsultor(trial.consultor || '');
    setStatus(trial.status || 'Implantado');
    setConvertedToSale(trial.convertedToSale || false);
    setSaleValue(trial.saleValue !== undefined ? String(trial.saleValue) : '');
    setAdditionalProducts(trial.additionalProducts || []);
    setAutoFilledNotice(false);
    setShowAddForm(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!producer || !product || !crop || !sowingDate || !farmName || !municipalityUf || !safra || !filial || !consultor) {
      alert('Por favor, preencha todos os campos obrigatórios (os marcados com *).');
      return;
    }

    const tcheArea = harvestedAreaTche.trim() ? parseFloat(harvestedAreaTche) : undefined;
    const tcheBags = bagsPerHaTche.trim() ? parseFloat(bagsPerHaTche) : undefined;
    const stdArea = harvestedAreaStandard.trim() ? parseFloat(harvestedAreaStandard) : undefined;
    const stdBags = bagsPerHaStandard.trim() ? parseFloat(bagsPerHaStandard) : undefined;
    const parsedSaleValue = convertedToSale && saleValue.trim() ? parseFloat(saleValue) : 0;

    if (editingTrialId && onEditTrial) {
      const updatedTrial: Trial = {
        id: editingTrialId,
        type,
        producer: producer.trim(),
        product: product.trim(),
        productTche: productTche.trim() || undefined,
        productStandard: productStandard.trim() || undefined,
        crop: crop.trim(),
        sowingDate,
        applicationDate: applicationDate || undefined,
        harvestDate: harvestDate || undefined,
        farmName: farmName.trim(),
        municipalityUf: municipalityUf.trim(),
        notes: notes.trim() || undefined,
        harvestedAreaTche: tcheArea,
        bagsPerHaTche: tcheBags,
        harvestedAreaStandard: stdArea,
        bagsPerHaStandard: stdBags,
        
        // novos campos
        safra,
        filial: filial.trim(),
        consultor: consultor.trim(),
        status,
        convertedToSale,
        saleValue: parsedSaleValue,
        additionalProducts: additionalProducts.length > 0 ? additionalProducts : undefined,
        createdAt: new Date().toISOString(), // keep or update time
      };
      onEditTrial(updatedTrial);
      resetForm();
      setShowAddForm(false);
    } else {
      const newTrial: Trial = {
        id: `trial-${Date.now()}`,
        type,
        producer: producer.trim(),
        product: product.trim(),
        productTche: productTche.trim() || undefined,
        productStandard: productStandard.trim() || undefined,
        crop: crop.trim(),
        sowingDate,
        applicationDate: applicationDate || undefined,
        harvestDate: harvestDate || undefined,
        farmName: farmName.trim(),
        municipalityUf: municipalityUf.trim(),
        notes: notes.trim() || undefined,
        harvestedAreaTche: tcheArea,
        bagsPerHaTche: tcheBags,
        harvestedAreaStandard: stdArea,
        bagsPerHaStandard: stdBags,
        
        // novos campos
        safra,
        filial: filial.trim(),
        consultor: consultor.trim(),
        status,
        convertedToSale,
        saleValue: parsedSaleValue,
        additionalProducts: additionalProducts.length > 0 ? additionalProducts : undefined,
        createdAt: new Date().toISOString(),
      };
      onAddTrial(newTrial);
      resetForm();
      setShowAddForm(false);
    }
  };

  const exportToExcel = () => {
    if (trials.length === 0) {
      alert('Não há dados de testes cadastrados para exportar.');
      return;
    }

    // Cabeçalhos do CSV estruturados para o Excel com localidade brasileira (separado por ponto-e-vírgula e codificado com BOM)
    const headers = [
      'ID do Teste',
      'Tipo de Teste',
      'Produtor Rural',
      'Fazenda',
      'Municipio/UF',
      'Cultura',
      'Nome Geral do Teste',
      'Produto Utilizado Tchê',
      'Produto Utilizado Padrão',
      'Data de Semeadura (Plantio)',
      'Data de Aplicação',
      'Data da Colheita',
      'Area Colhida Tche (ha)',
      'Produtividade Tche (sc/ha)',
      'Area Colhida Padrao (ha)',
      'Produtividade Padrao (sc/ha)',
      'Resultado Ganho/Diferenca (sc/ha)',
      'Observações Adicionais'
    ];

    const rows = trials.map(t => {
      const typeLabel = t.type === 'Nutri' ? 'Nutrição' : t.type === 'Bio' ? 'Biológico' : 'Semente';
      const parsedDiff = (t.bagsPerHaTche !== undefined && t.bagsPerHaStandard !== undefined) 
        ? (t.bagsPerHaTche - t.bagsPerHaStandard).toFixed(2) 
        : '';
      
      return [
        t.id,
        typeLabel,
        t.producer.replace(/;/g, ','),
        t.farmName.replace(/;/g, ','),
        t.municipalityUf.replace(/;/g, ','),
        t.crop.replace(/;/g, ','),
        t.product.replace(/;/g, ','),
        (t.productTche || 'Não cadastrado').replace(/;/g, ','),
        (t.productStandard || 'Não cadastrado').replace(/;/g, ','),
        t.sowingDate,
        t.applicationDate || 'Não realizada',
        t.harvestDate || 'Não colhido',
        t.harvestedAreaTche !== undefined ? String(t.harvestedAreaTche).replace('.', ',') : 'N/A',
        t.bagsPerHaTche !== undefined ? String(t.bagsPerHaTche).replace('.', ',') : 'N/A',
        t.harvestedAreaStandard !== undefined ? String(t.harvestedAreaStandard).replace('.', ',') : 'N/A',
        t.bagsPerHaStandard !== undefined ? String(t.bagsPerHaStandard).replace('.', ',') : 'N/A',
        parsedDiff.replace('.', ','),
        (t.notes || '').replace(/[\n\r]/g, ' ').replace(/;/g, ',')
      ];
    });

    const csvContent = "\uFEFF" // UTF-8 BOM
      + [headers.join(';'), ...rows.map(e => e.join(';'))].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `lado_a_lado_tche_${getTodayDateString()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const filteredTrials = trials.filter((t) => {
    const matchesSearch =
      t.producer.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.product.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.crop.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.farmName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.municipalityUf.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesType = typeFilter === 'All' || t.type === typeFilter;
    return matchesSearch && matchesType;
  });
  const getBadgeColors = (t: TrialType) => {
    switch (t) {
      case 'Nutri':
        return 'bg-emerald-50 text-emerald-800 border border-emerald-150';
      case 'Bio':
        return 'bg-teal-50 text-teal-800 border border-teal-150';
      case 'Semente':
        return 'bg-amber-50 text-amber-800 border border-amber-150';
      default:
        return 'bg-stone-50 text-stone-700 border border-stone-200';
    }
  };

  const getStatusBadgeColors = (status: TrialStatus) => {
    switch (status) {
      case 'Implantado':
        return 'bg-amber-50 text-amber-800 border border-amber-150';
      case 'Em Andamento':
        return 'bg-blue-50 text-blue-800 border border-blue-150';
      case 'Colhido':
        return 'bg-emerald-50 text-emerald-800 border border-emerald-150';
      case 'Entregue':
        return 'bg-purple-50 text-purple-800 border border-purple-150';
      default:
        return 'bg-stone-50 text-stone-750 border border-stone-150';
    }
  };

  const getTypeLabel = (t: TrialType) => {
    switch (t) {
      case 'Nutri': return 'Nutrição';
      case 'Bio': return 'Biológico';
      case 'Semente': return 'Semente';
      default: return t;
    }
  };

  const countByType = (t: TrialType | 'All') => {
    if (t === 'All') return trials.length;
    return trials.filter(trial => trial.type === t).length;
  };

  return (
    <div className="space-y-6">
      {/* Upper header action item */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 id="trials-header" className="text-lg font-bold tracking-tight text-stone-900 flex items-center gap-2">
            <Sprout className="w-5 h-5 text-green-700" />
            Registro de Testes de Campo Lado a Lado
          </h2>
          <p className="text-xs text-stone-500">
            Cadastre e monitore os campos de testes comerciais instalados em produtores parceiros.
          </p>
        </div>
        <div className="flex flex-wrap gap-2 self-start sm:self-center">
          <button
            type="button"
            onClick={exportToExcel}
            className="flex items-center justify-center gap-2 px-3 py-2 bg-white hover:bg-stone-50 text-stone-700 text-xs font-bold rounded shadow-3xs hover:shadow-2xs border border-stone-200 transition-all cursor-pointer uppercase tracking-wider"
            title="Exportar dados de campo para o Excel"
          >
            <FileSpreadsheet className="w-4 h-4 text-green-700" />
            Exportar Excel
          </button>
          <button
            id="btn-new-trial"
            onClick={() => {
              if (showAddForm) {
                resetForm();
                setShowAddForm(false);
              } else {
                resetForm();
                setShowAddForm(true);
              }
            }}
            className="flex items-center justify-center gap-2 px-3.5 py-2 bg-green-700 hover:bg-green-800 text-white text-xs font-bold rounded shadow-xs transition-all cursor-pointer uppercase tracking-wider border border-green-700"
          >
            {showAddForm ? 'Fechar Formulário' : (
              <>
                <Plus className="w-4 h-4" />
                Novo Registro LAL
              </>
            )}
          </button>
        </div>
      </div>

      {/* Add / Edit Form */}
      {showAddForm && (
        <form
          id="trial-form"
          onSubmit={handleSubmit}
          className="relative overflow-hidden bg-white border border-stone-200 rounded p-5 shadow-xs transition-all"
        >
          {/* Top colored strip indicator */}
          <div className="absolute top-0 left-0 right-0 h-1 bg-green-700" />

          <h3 className="text-xs font-bold text-stone-900 uppercase tracking-wider mb-4 flex items-center gap-1.5 mt-1">
            <Sprout className="w-4 h-4 text-green-700" />
            {editingTrialId ? 'Editar Detalhes do Teste' : 'Novo Teste Lado a Lado'}
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Tipo de Teste */}
            <div>
              <label htmlFor="field-type" className="block text-[11px] font-bold text-stone-600 uppercase tracking-wider mb-1">
                Tipo do Teste *
              </label>
              <select
                id="field-type"
                value={type}
                onChange={(e) => setType(e.target.value as TrialType)}
                className="w-full bg-stone-50 border border-stone-200 text-stone-800 text-xs rounded focus:ring-1 focus:ring-stone-400 focus:border-stone-400 p-2 outline-none transition font-sans"
              >
                <option value="Nutri">Nutrição (Nutri)</option>
                <option value="Bio">Biológico (Bio)</option>
                <option value="Semente">Semente</option>
              </select>
            </div>

            {/* Produtor com datalist de sugestão e aviso de preenchimento automático */}
            <div>
              <label htmlFor="field-producer" className="block text-[11px] font-bold text-stone-600 uppercase tracking-wider mb-1">
                Produtor Rural *
              </label>
              <input
                type="text"
                id="field-producer"
                list="producers-datalist"
                required
                placeholder="Exemplo: João Carlos Ribeiro"
                value={producer}
                onChange={(e) => handleProducerChange(e.target.value)}
                className="w-full bg-stone-50 border border-stone-200 text-stone-800 placeholder:text-stone-400 text-xs rounded focus:ring-1 focus:ring-stone-400 focus:border-stone-400 p-2 outline-none transition font-sans"
              />
              <datalist id="producers-datalist">
                {Array.from(new Set(trials.map(t => t.producer.trim()))).filter(Boolean).map(p => (
                  <option key={p} value={p} />
                ))}
              </datalist>
              {autoFilledNotice && (
                <p className="text-[9px] text-green-700 bg-green-50 p-1 rounded border border-green-200 mt-1.5 font-sans font-semibold">
                  ✓ Dados da Fazenda, Localidade, Filial e Consultor foram preenchidos automaticamente!
                </p>
              )}
            </div>

            {/* Nome da Fazenda */}
            <div>
              <label htmlFor="field-farm" className="block text-[11px] font-bold text-stone-600 uppercase tracking-wider mb-1">
                Nome da Fazenda *
              </label>
              <input
                type="text"
                id="field-farm"
                required
                placeholder="Exemplo: Fazenda Boa Esperança"
                value={farmName}
                onChange={(e) => setFarmName(e.target.value)}
                className="w-full bg-stone-50 border border-stone-200 text-stone-800 placeholder:text-stone-400 text-xs rounded focus:ring-1 focus:ring-stone-400 focus:border-stone-400 p-2 outline-none transition font-sans"
              />
            </div>

            {/* Produto de Referência Geral */}
            <div>
              <label htmlFor="field-product" className="block text-[11px] font-bold text-stone-600 uppercase tracking-wider mb-1">
                Nome do Teste Geral *
              </label>
              <input
                type="text"
                id="field-product"
                required
                placeholder="Exemplo: Biofúngico XP vs Padrão"
                value={product}
                onChange={(e) => setProduct(e.target.value)}
                className="w-full bg-stone-50 border border-stone-200 text-stone-800 placeholder:text-stone-400 text-xs rounded focus:ring-1 focus:ring-stone-400 focus:border-stone-400 p-2 outline-none transition font-sans"
              />
            </div>

            {/* Cultura */}
            <div>
              <label htmlFor="field-crop" className="block text-[11px] font-bold text-stone-600 uppercase tracking-wider mb-1">
                Cultura *
              </label>
              <input
                type="text"
                id="field-crop"
                required
                placeholder="Exemplo: Soja, Milho, Algodão"
                value={crop}
                onChange={(e) => setCrop(e.target.value)}
                className="w-full bg-stone-50 border border-stone-200 text-stone-800 placeholder:text-stone-400 text-xs rounded focus:ring-1 focus:ring-stone-400 focus:border-stone-400 p-2 outline-none transition font-sans"
              />
            </div>

            {/* Município / UF */}
            <div>
              <label htmlFor="field-municipality" className="block text-[11px] font-bold text-stone-600 uppercase tracking-wider mb-1">
                Município / UF *
              </label>
              <input
                type="text"
                id="field-municipality"
                required
                placeholder="Exemplo: Sorriso/MT"
                value={municipalityUf}
                onChange={(e) => setMunicipalityUf(e.target.value)}
                className="w-full bg-stone-50 border border-stone-200 text-stone-800 placeholder:text-stone-400 text-xs rounded focus:ring-1 focus:ring-stone-400 focus:border-stone-400 p-2 outline-none transition font-sans"
              />
            </div>

            {/* Safra */}
            <div>
              <label htmlFor="field-safra" className="block text-[11px] font-bold text-stone-600 uppercase tracking-wider mb-1 flex justify-between items-center">
                <span>Safra *</span>
                <button
                  type="button"
                  onClick={() => setCustomSafraMode(!customSafraMode)}
                  className="text-[9px] font-bold text-green-700 hover:underline uppercase"
                >
                  {customSafraMode ? 'Ver Lista' : 'Digitar Outra'}
                </button>
              </label>
              {customSafraMode ? (
                <input
                  type="text"
                  id="field-safra"
                  required
                  placeholder="Ex: 27/28 ou 2026"
                  value={safra}
                  onChange={(e) => setSafra(e.target.value)}
                  className="w-full bg-stone-50 border border-stone-200 text-stone-800 text-xs rounded focus:ring-1 focus:ring-stone-400 focus:border-stone-400 p-2 outline-none transition font-sans"
                />
              ) : (
                <select
                  id="field-safra"
                  required
                  value={safra}
                  onChange={(e) => {
                    if (e.target.value === 'custom') {
                      setCustomSafraMode(true);
                      setSafra('');
                    } else {
                      setSafra(e.target.value);
                    }
                  }}
                  className="w-full bg-stone-50 border border-stone-200 text-stone-800 text-xs rounded focus:ring-1 focus:ring-stone-400 focus:border-stone-400 p-2 outline-none transition font-sans"
                >
                  <option value="25/26">25/26</option>
                  <option value="24/25">24/25</option>
                  <option value="23/24">23/24</option>
                  <option value="26/27">26/27</option>
                  <option value="custom">+ Adicionar outra safra...</option>
                </select>
              )}
            </div>

            {/* Filial */}
            <div>
              <label htmlFor="field-filial" className="block text-[11px] font-bold text-stone-600 uppercase tracking-wider mb-1">
                Filial *
              </label>
              <input
                type="text"
                id="field-filial"
                required
                placeholder="Exemplo: Filial Cascavel"
                value={filial}
                onChange={(e) => setFilial(e.target.value)}
                className="w-full bg-stone-50 border border-stone-200 text-stone-800 placeholder:text-stone-400 text-xs rounded focus:ring-1 focus:ring-stone-400 focus:border-stone-400 p-2 outline-none transition font-sans"
              />
            </div>

            {/* Consultor */}
            <div>
              <label htmlFor="field-consultor" className="block text-[11px] font-bold text-stone-600 uppercase tracking-wider mb-1">
                Consultor Responsável *
              </label>
              <input
                type="text"
                id="field-consultor"
                required
                placeholder="Exemplo: Carlos Souza"
                value={consultor}
                onChange={(e) => setConsultor(e.target.value)}
                className="w-full bg-stone-50 border border-stone-200 text-stone-800 placeholder:text-stone-400 text-xs rounded focus:ring-1 focus:ring-stone-400 focus:border-stone-400 p-2 outline-none transition font-sans"
              />
            </div>

            {/* Status do Teste */}
            <div>
              <label htmlFor="field-status" className="block text-[11px] font-bold text-stone-600 uppercase tracking-wider mb-1">
                Status do Teste *
              </label>
              <select
                id="field-status"
                required
                value={status}
                onChange={(e) => setStatus(e.target.value as TrialStatus)}
                className="w-full bg-stone-50 border border-stone-200 text-stone-800 text-xs rounded focus:ring-1 focus:ring-stone-400 focus:border-stone-400 p-2 outline-none transition font-sans"
              >
                <option value="Implantado">Implantado</option>
                <option value="Em Andamento">Em Andamento</option>
                <option value="Colhido">Colhido</option>
                <option value="Entregue">Entregue</option>
              </select>
            </div>

            {/* Datas */}
            <div>
              <label htmlFor="field-sowing" className="block text-[11px] font-bold text-stone-600 uppercase tracking-wider mb-1">
                Data de Semeadura (Plantio) *
              </label>
              <input
                type="date"
                id="field-sowing"
                required
                value={sowingDate}
                onChange={(e) => setSowingDate(e.target.value)}
                className="w-full bg-stone-50 border border-stone-200 text-stone-800 text-xs rounded focus:ring-1 focus:ring-stone-400 focus:border-stone-400 p-1.5 outline-none transition font-mono"
              />
            </div>

            <div>
              <label htmlFor="field-app" className="block text-[11px] font-bold text-stone-600 uppercase tracking-wider mb-1">
                Data de Aplicação (Opcional)
              </label>
              <input
                type="date"
                id="field-app"
                value={applicationDate}
                onChange={(e) => setApplicationDate(e.target.value)}
                className="w-full bg-stone-50 border border-stone-200 text-stone-800 text-xs rounded focus:ring-1 focus:ring-stone-400 focus:border-stone-400 p-1.5 outline-none transition font-mono"
              />
            </div>

            <div>
              <label htmlFor="field-harvest" className="block text-[11px] font-bold text-stone-600 uppercase tracking-wider mb-1">
                Data da Colheita (Opcional)
              </label>
              <input
                type="date"
                id="field-harvest"
                value={harvestDate}
                onChange={(e) => setHarvestDate(e.target.value)}
                className="w-full bg-stone-50 border border-stone-200 text-stone-800 text-xs rounded focus:ring-1 focus:ring-stone-400 focus:border-stone-400 p-1.5 outline-none transition font-mono"
              />
            </div>

            {/* Ativos/Tratamentos Comparativos Heading */}
            <div className="col-span-1 md:col-span-3 border-t border-stone-250/50 pt-3 mt-1">
              <h4 className="text-[10px] font-bold text-green-700 uppercase tracking-widest">
                Produtos Utilizados no Lado a Lado
              </h4>
            </div>

            {/* Produto Utilizado Tchê */}
            <div>
              <label htmlFor="field-product-tche" className="block text-[11px] font-bold text-stone-600 uppercase tracking-wider mb-1">
                Produto Utilizado Tchê
              </label>
              <input
                type="text"
                id="field-product-tche"
                placeholder="Exemplo: Nutrição Folha Tchê"
                value={productTche}
                onChange={(e) => setProductTche(e.target.value)}
                className="w-full bg-green-50/30 border border-green-200/65 text-stone-800 placeholder:text-stone-400 text-xs rounded focus:ring-1 focus:ring-green-400 focus:border-green-400 p-2 outline-none transition font-sans"
              />
            </div>

            {/* Produto Utilizado Padrão */}
            <div>
              <label htmlFor="field-product-standard" className="block text-[11px] font-bold text-stone-600 uppercase tracking-wider mb-1">
                Produto Utilizado Padrão
              </label>
              <input
                type="text"
                id="field-product-standard"
                placeholder="Exemplo: Tratamento Padrão de Mercado"
                value={productStandard}
                onChange={(e) => setProductStandard(e.target.value)}
                className="w-full bg-stone-50 border border-stone-200 text-stone-800 placeholder:text-stone-400 text-xs rounded focus:ring-1 focus:ring-stone-400 focus:border-stone-400 p-2 outline-none transition font-sans"
              />
            </div>

            <div className="hidden md:block" />

            {/* Colheita / Produtividade Lado a Lado Heading */}
            <div className="col-span-1 md:col-span-3 border-t border-stone-250/50 pt-4 mt-1">
              <h4 className="text-[10px] font-bold text-green-700 uppercase tracking-widest">
                Dados de Produtividade à Colheita (Opcional)
              </h4>
            </div>

            {/* Tchê Area / Bags */}
            <div className="bg-green-50/20 border border-green-150 p-3 rounded space-y-3">
              <span className="text-[10px] font-bold text-green-800 uppercase tracking-wider block border-b border-green-100 pb-1">Área Tchê</span>
              <div>
                <label htmlFor="field-area-tche" className="block text-[10px] font-semibold text-stone-600 uppercase tracking-wide mb-1">
                  Área Colhida (ha)
                </label>
                <input
                  type="number"
                  step="any"
                  id="field-area-tche"
                  placeholder="Exemplo: 12.5"
                  value={harvestedAreaTche}
                  onChange={(e) => setHarvestedAreaTche(e.target.value)}
                  className="w-full bg-white border border-stone-200 text-stone-800 text-xs rounded p-1.5 outline-none focus:ring-1 focus:ring-green-400"
                />
              </div>
              <div>
                <label htmlFor="field-bags-tche" className="block text-[10px] font-semibold text-stone-600 uppercase tracking-wide mb-1">
                  Sacas por Hectare (Sacas/ha)
                </label>
                <input
                  type="number"
                  step="any"
                  id="field-bags-tche"
                  placeholder="Exemplo: 78.4"
                  value={bagsPerHaTche}
                  onChange={(e) => setBagsPerHaTche(e.target.value)}
                  className="w-full bg-white border border-stone-200 text-stone-800 text-xs rounded p-1.5 outline-none focus:ring-1 focus:ring-green-400"
                />
              </div>
            </div>

            {/* Padrão Area / Bags */}
            <div className="bg-stone-50/50 border border-stone-200 p-3 rounded space-y-3">
              <span className="text-[10px] font-bold text-stone-700 uppercase tracking-wider block border-b border-stone-200 pb-1">Área Padrão</span>
              <div>
                <label htmlFor="field-area-std" className="block text-[10px] font-semibold text-stone-600 uppercase tracking-wide mb-1">
                  Área Colhida (ha)
                </label>
                <input
                  type="number"
                  step="any"
                  id="field-area-std"
                  placeholder="Exemplo: 12.5"
                  value={harvestedAreaStandard}
                  onChange={(e) => setHarvestedAreaStandard(e.target.value)}
                  className="w-full bg-white border border-stone-200 text-stone-800 text-xs rounded p-1.5 outline-none focus:ring-1 focus:ring-stone-400"
                />
              </div>
              <div>
                <label htmlFor="field-bags-std" className="block text-[10px] font-semibold text-stone-600 uppercase tracking-wide mb-1">
                  Sacas por Hectare (Sacas/ha)
                </label>
                <input
                  type="number"
                  step="any"
                  id="field-bags-std"
                  placeholder="Exemplo: 71.2"
                  value={bagsPerHaStandard}
                  onChange={(e) => setBagsPerHaStandard(e.target.value)}
                  className="w-full bg-white border border-stone-200 text-stone-800 text-xs rounded p-1.5 outline-none focus:ring-1 focus:ring-stone-400"
                />
              </div>
            </div>

            <div className="hidden md:block" />

            {/* Conversão em Vendas Heading */}
            <div className="col-span-1 md:col-span-3 border-t border-stone-250/50 pt-4 mt-1">
              <h4 className="text-[10px] font-bold text-green-700 uppercase tracking-widest">
                Conversão em Vendas Comerciais
              </h4>
            </div>

            {/* Conversão em Vendas checkbox/toggle and estimated sales value */}
            <div className="col-span-1 md:col-span-3 bg-stone-50/50 p-3.5 rounded border border-stone-200 flex flex-col md:flex-row gap-4 items-start md:items-center">
              <label className="flex items-center gap-2.5 cursor-pointer text-xs font-bold text-stone-700 uppercase tracking-wider select-none shrink-0">
                <input
                  type="checkbox"
                  checked={convertedToSale}
                  onChange={(e) => setConvertedToSale(e.target.checked)}
                  className="w-4 h-4 text-green-700 border-stone-350 focus:ring-green-500 cursor-pointer rounded"
                />
                <span>O teste foi convertido em venda?</span>
              </label>

              {convertedToSale && (
                <div className="flex-1 w-full max-w-sm">
                  <label htmlFor="field-sale-value" className="block text-[10px] font-semibold text-stone-600 uppercase tracking-wide mb-1">
                    Valor Estimado de Vendas Gerado (R$) *
                  </label>
                  <input
                    type="number"
                    step="any"
                    id="field-sale-value"
                    required={convertedToSale}
                    placeholder="Exemplo: 25000"
                    value={saleValue}
                    onChange={(e) => setSaleValue(e.target.value)}
                    className="w-full bg-white border border-stone-200 text-stone-800 text-xs rounded p-1.5 outline-none focus:ring-1 focus:ring-green-450"
                  />
                </div>
              )}
            </div>

            {/* Outros Produtos e Produtividades Adicionais */}
            <div className="col-span-1 md:col-span-3 border-t border-stone-250/50 pt-4 mt-2">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <h4 className="text-[10px] font-bold text-green-700 uppercase tracking-widest flex items-center gap-1.5">
                  Outros Produtos & Produtividades no Teste (Opcional)
                </h4>
                <button
                  type="button"
                  onClick={() => {
                    setAdditionalProducts([
                      ...additionalProducts,
                      {
                        id: `add-prod-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
                        name: '',
                        category: 'Tche',
                        harvestedArea: undefined,
                        bagsPerHa: undefined
                      }
                    ]);
                  }}
                  className="px-2.5 py-1 text-[10px] bg-green-50 text-green-700 border border-green-200 rounded font-bold hover:bg-green-100 transition flex items-center gap-1 cursor-pointer uppercase tracking-wider"
                >
                  <Plus className="w-3.5 h-3.5" /> Adicionar Produto
                </button>
              </div>
              <p className="text-[10.5px] text-stone-500 mt-1">
                Adicione outros produtos avaliados simultaneamente no mesmo teste lado a lado para computar a produtividade de cada um de forma independente.
              </p>
            </div>

            {additionalProducts.length > 0 && (
              <div className="col-span-1 md:col-span-3 space-y-3 bg-stone-50/50 p-4 rounded border border-stone-200">
                {additionalProducts.map((addProd, idx) => (
                  <div key={addProd.id} className="grid grid-cols-1 md:grid-cols-12 gap-3 items-end bg-white p-3 rounded border border-stone-200 shadow-3xs relative pr-8">
                    <button
                      type="button"
                      onClick={() => {
                        setAdditionalProducts(additionalProducts.filter(p => p.id !== addProd.id));
                      }}
                      className="absolute top-2 right-2 text-stone-400 hover:text-red-600 transition cursor-pointer p-1"
                      title="Remover produto adicional"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>

                    {/* Nome do Produto */}
                    <div className="md:col-span-4">
                      <label className="block text-[10px] font-semibold text-stone-600 uppercase mb-1">
                        Produto Adicional *
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="Ex: Potássio Tchê, Defensivo Padrão"
                        value={addProd.name}
                        onChange={(e) => {
                          const updated = [...additionalProducts];
                          updated[idx].name = e.target.value;
                          setAdditionalProducts(updated);
                        }}
                        className="w-full bg-stone-50 border border-stone-200 text-stone-800 text-xs rounded p-1.5 outline-none focus:ring-1 focus:ring-green-400"
                      />
                    </div>

                    {/* Categoria: Tchê ou Padrão */}
                    <div className="md:col-span-2">
                      <label className="block text-[10px] font-semibold text-stone-600 uppercase mb-1">
                        Tratamento *
                      </label>
                      <select
                        value={addProd.category}
                        onChange={(e) => {
                          const updated = [...additionalProducts];
                          updated[idx].category = e.target.value as 'Tche' | 'Padrão';
                          setAdditionalProducts(updated);
                        }}
                        className="w-full bg-stone-50 border border-stone-200 text-stone-800 text-xs rounded p-1.5 outline-none focus:ring-1 focus:ring-green-400 font-sans"
                      >
                        <option value="Tche">Tchê (Nutrição/Bio)</option>
                        <option value="Padrão">Padrão (Fazenda)</option>
                      </select>
                    </div>

                    {/* Área colhida */}
                    <div className="md:col-span-3">
                      <label className="block text-[10px] font-semibold text-stone-600 uppercase mb-1">
                        Área Colhida (ha)
                      </label>
                      <input
                        type="number"
                        step="any"
                        placeholder="Ex: 5"
                        value={addProd.harvestedArea !== undefined ? addProd.harvestedArea : ''}
                        onChange={(e) => {
                          const updated = [...additionalProducts];
                          updated[idx].harvestedArea = e.target.value ? parseFloat(e.target.value) : undefined;
                          setAdditionalProducts(updated);
                        }}
                        className="w-full bg-stone-50 border border-stone-200 text-stone-800 text-xs rounded p-1.5 outline-none focus:ring-1 focus:ring-green-400"
                      />
                    </div>

                    {/* Produtividade */}
                    <div className="md:col-span-3">
                      <label className="block text-[10px] font-semibold text-stone-600 uppercase mb-1">
                        Produtividade (Sacas/ha)
                      </label>
                      <input
                        type="number"
                        step="any"
                        placeholder="Ex: 81.2"
                        value={addProd.bagsPerHa !== undefined ? addProd.bagsPerHa : ''}
                        onChange={(e) => {
                          const updated = [...additionalProducts];
                          updated[idx].bagsPerHa = e.target.value ? parseFloat(e.target.value) : undefined;
                          setAdditionalProducts(updated);
                        }}
                        className="w-full bg-stone-50 border border-stone-200 text-stone-800 text-xs rounded p-1.5 outline-none focus:ring-1 focus:ring-green-400"
                      />
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Observações Heading */}
            <div className="col-span-1 md:col-span-3 border-t border-stone-250/55 pt-4 mt-1">
              <h4 className="text-[10px] font-bold text-green-700 uppercase tracking-widest">
                Observações Adicionais do Teste
              </h4>
            </div>

            {/* Textarea Observações */}
            <div className="col-span-1 md:col-span-3">
              <textarea
                id="field-notes"
                rows={3}
                placeholder="Insira detalhes adicionais do teste de campo lado a lado (exemplo: histórico do talhão, condições climáticas durante a semeadura, observações de nematoides, etc.)"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full bg-stone-50 border border-stone-200 text-stone-800 placeholder:text-stone-400 text-xs rounded focus:ring-1 focus:ring-stone-400 focus:border-stone-400 p-2.5 outline-none transition font-sans resize-y"
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-2.5 mt-5 pt-4 border-t border-stone-150">
            <button
              type="button"
              onClick={() => {
                resetForm();
                setShowAddForm(false);
              }}
              className="px-4 py-2 text-xs font-bold text-stone-500 hover:text-stone-700 bg-transparent hover:bg-stone-50 border border-transparent rounded transition uppercase"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-bold text-white bg-green-700 hover:bg-green-800 rounded shadow-xs transition uppercase"
            >
              {editingTrialId ? 'Salvar Alterações' : 'Salvar Registro'}
            </button>
          </div>
        </form>
      )}

      {/* Filters and search section */}
      <div className="bg-stone-100/80 border border-stone-200 rounded p-4 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        {/* Type tabs toggler */}
        <div className="flex flex-wrap items-center gap-1 bg-stone-200/60 p-1 rounded">
          <button
            onClick={() => setTypeFilter('All')}
            className={`px-3 py-1.5 text-xs font-bold rounded transition ${
              typeFilter === 'All'
                ? 'bg-green-700 text-white shadow-xs'
                : 'text-stone-500 hover:text-green-800 hover:bg-green-50/20'
            }`}
          >
            Todos ({countByType('All')})
          </button>
          <button
            onClick={() => setTypeFilter('Nutri')}
            className={`px-3 py-1.5 text-xs font-bold rounded transition ${
              typeFilter === 'Nutri'
                ? 'bg-emerald-700 text-white shadow-xs'
                : 'text-stone-500 hover:text-emerald-700 hover:bg-green-50/20'
            }`}
          >
            Nutrição ({countByType('Nutri')})
          </button>
          <button
            onClick={() => setTypeFilter('Bio')}
            className={`px-3 py-1.5 text-xs font-bold rounded transition ${
              typeFilter === 'Bio'
                ? 'bg-teal-700 text-white shadow-xs'
                : 'text-stone-500 hover:text-teal-700 hover:bg-teal-50/20'
            }`}
          >
            Biológico ({countByType('Bio')})
          </button>
          <button
            onClick={() => setTypeFilter('Semente')}
            className={`px-3 py-1.5 text-xs font-bold rounded transition ${
              typeFilter === 'Semente'
                ? 'bg-amber-700 text-white shadow-xs'
                : 'text-stone-500 hover:text-amber-700 hover:bg-amber-50/20'
            }`}
          >
            Semente ({countByType('Semente')})
          </button>
        </div>

        {/* Text Filter */}
        <div className="relative flex-1 md:max-w-md">
          <Search className="absolute left-3 top-2.5 w-4 h-4 text-stone-400" />
          <input
            type="text"
            placeholder="Buscar por produtor, cultura, ativo, fazenda, cidade..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-white border border-stone-200 text-stone-800 placeholder:text-stone-400 text-xs rounded pl-9 pr-4 py-2 focus:ring-1 focus:ring-stone-400 focus:border-stone-400 outline-none transition font-sans"
          />
        </div>
      </div>

      {/* Grid or Empty view */}
      {filteredTrials.length === 0 ? (
        <div className="bg-white border border-stone-200 rounded p-10 text-center flex flex-col items-center justify-center">
          <div className="w-12 h-12 rounded-full bg-stone-50 text-stone-400 flex items-center justify-center mb-3 border border-stone-150">
            <Sprout className="w-6 h-6" />
          </div>
          <p className="text-xs font-bold uppercase tracking-wider text-stone-700">Nenhum teste encontrado</p>
          <p className="text-xs text-stone-500 mt-1.5 max-w-sm">
            {searchTerm || typeFilter !== 'All' 
              ? 'Tente alterar os termos da busca ou filtros selecionados.' 
              : 'Clique em "Novo Registro LAL" para cadastrar seu primeiro teste de campo.'}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredTrials.map((trial) => (
            <div
              key={trial.id}
              className="group bg-white border border-stone-200 hover:border-stone-400 rounded p-4 shadow-3xs hover:shadow-2xs transition-all flex flex-col justify-between"
            >
              {/* Card Header information */}
              <div>
                <div className="flex items-center justify-between gap-2 mb-3">
                  <div className="flex flex-wrap items-center gap-1">
                    <span className={`px-2 py-0.5 text-[9px] font-bold tracking-widest uppercase rounded ${getBadgeColors(trial.type)}`}>
                      {getTypeLabel(trial.type)}
                    </span>
                    <span className={`px-2 py-0.5 text-[9px] font-bold tracking-wider uppercase rounded border ${getStatusBadgeColors(trial.status || 'Implantado')}`}>
                      {trial.status || 'Implantado'}
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 opacity-80 group-hover:opacity-100 transition">
                    <button
                      onClick={() => handleEditInit(trial)}
                      title="Editar teste"
                      className="p-1 text-stone-400 hover:text-green-700 rounded hover:bg-stone-50 cursor-pointer border border-transparent"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => {
                        if (confirm(`Excluir o teste de ${trial.producer}? Todas as visitas a este teste serão mantidas, porém sem referência de semeadura original.`)) {
                          onDeleteTrial(trial.id);
                        }
                      }}
                      title="Excluir teste"
                      className="p-1 text-stone-400 hover:text-red-600 rounded hover:bg-stone-50 cursor-pointer border border-transparent"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <h4 className="text-sm font-bold text-stone-900 line-clamp-1 group-hover:text-green-800 transition">
                  {trial.producer}
                </h4>

                <div className="mt-2.5 space-y-1.5 font-sans text-xs">
                  {/* Fazenda */}
                  <div className="flex items-start gap-1.5 text-stone-650">
                    <FileSpreadsheet className="w-3.5 h-3.5 text-stone-400 shrink-0 mt-0.5" />
                    <span className="line-clamp-1">
                      <span className="text-stone-450 font-medium">Fazenda: </span>{trial.farmName}
                    </span>
                  </div>

                  {/* Município/UF */}
                  <div className="flex items-start gap-1.5 text-stone-650">
                    <MapPin className="w-3.5 h-3.5 text-stone-400 shrink-0 mt-0.5" />
                    <span className="line-clamp-1">
                      <span className="text-stone-450 font-medium">Região: </span>{trial.municipalityUf}
                    </span>
                  </div>

                  {/* Safra, Filial e Consultor */}
                  <div className="grid grid-cols-2 gap-2 pt-1 border-t border-stone-100 text-[10px] text-stone-600">
                    <div>
                      <span className="text-stone-450 font-medium text-[8.5px] uppercase tracking-wide block">Safra:</span>
                      <span className="font-extrabold text-stone-800">{trial.safra || '25/26'}</span>
                    </div>
                    <div>
                      <span className="text-stone-450 font-medium text-[8.5px] uppercase tracking-wide block">Filial:</span>
                      <span className="font-bold text-stone-850 truncate block" title={trial.filial}>{trial.filial || 'Geral'}</span>
                    </div>
                  </div>
                  <div className="text-[10px] text-stone-600">
                    <span className="text-stone-450 font-medium text-[8.5px] uppercase tracking-wide">Consultor: </span>
                    <span className="font-bold text-stone-800">{trial.consultor || 'Não informado'}</span>
                  </div>

                  {/* Cultura & Ativo */}
                  <div className="flex items-center gap-1.5 pt-1">
                    <span className="shrink-0 text-green-800 font-bold text-[9px] uppercase tracking-wide bg-green-50 px-2 py-0.5 rounded border border-green-150">
                      Cultura: {trial.crop}
                    </span>
                    <span className="text-stone-600 truncate font-semibold bg-stone-100 px-2 py-0.5 rounded border border-stone-200 text-[10px]">
                      {trial.product}
                    </span>
                  </div>

                  {/* Produtos Utilizados LAL */}
                  {(trial.productTche || trial.productStandard) && (
                    <div className="bg-stone-50 p-2 rounded border border-stone-150/60 space-y-1 mt-2 text-[10px]">
                      <span className="text-stone-400 block font-semibold text-[8px] uppercase tracking-wider">Tratamentos:</span>
                      {trial.productTche && (
                        <div className="flex items-center justify-between text-green-800 font-medium">
                          <span>📦 Tchê:</span>
                          <span className="font-semibold truncate max-w-[150px]">{trial.productTche}</span>
                        </div>
                      )}
                      {trial.productStandard && (
                        <div className="flex items-center justify-between text-stone-650">
                          <span>📦 Padrão:</span>
                          <span className="font-semibold truncate max-w-[150px]">{trial.productStandard}</span>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Produtividade Lado a Lado */}
                  {(trial.bagsPerHaTche !== undefined || trial.bagsPerHaStandard !== undefined) && (
                    <div className="bg-green-50/20 p-2 rounded border border-green-150/60 mt-2 text-[11px]">
                      <span className="text-green-800 block font-bold text-[8.5px] uppercase tracking-wider mb-1">Produtividade LAL:</span>
                      <div className="grid grid-cols-2 gap-2 text-center">
                        <div className="bg-green-50 p-1.5 rounded border border-green-100">
                          <span className="text-[8px] text-green-700 block uppercase tracking-wide font-bold">Tchê</span>
                          <span className="font-extrabold text-green-850 text-xs">
                            {trial.bagsPerHaTche !== undefined ? `${trial.bagsPerHaTche} sc/ha` : '-'}
                          </span>
                          {trial.harvestedAreaTche !== undefined && (
                            <span className="text-[8px] text-stone-450 block">({trial.harvestedAreaTche} ha)</span>
                          )}
                        </div>
                        <div className="bg-stone-50 p-1.5 rounded border border-stone-150">
                          <span className="text-[8px] text-stone-500 block uppercase tracking-wide font-bold">Padrão</span>
                          <span className="font-extrabold text-stone-750 text-xs">
                            {trial.bagsPerHaStandard !== undefined ? `${trial.bagsPerHaStandard} sc/ha` : '-'}
                          </span>
                          {trial.harvestedAreaStandard !== undefined && (
                            <span className="text-[8px] text-stone-450 block">({trial.harvestedAreaStandard} ha)</span>
                          )}
                        </div>
                      </div>
                      
                      {/* Cálculo do Incremento */}
                      {trial.bagsPerHaTche !== undefined && trial.bagsPerHaStandard !== undefined && (
                        <div className="mt-1.5 text-center text-[9.5px] font-bold text-green-850 bg-green-100/50 py-0.5 rounded border border-green-200">
                          {trial.bagsPerHaTche - trial.bagsPerHaStandard > 0 ? (
                            <span>🌱 Incremento Tchê: +{(trial.bagsPerHaTche - trial.bagsPerHaStandard).toFixed(1)} sc/ha</span>
                          ) : trial.bagsPerHaTche - trial.bagsPerHaStandard < 0 ? (
                            <span className="text-amber-800">🌱 Padrão superior em: +{(trial.bagsPerHaStandard - trial.bagsPerHaTche).toFixed(1)} sc/ha</span>
                          ) : (
                            <span>🌱 Produtividades Equivalentes</span>
                          )}
                        </div>
                      )}
                    </div>
                  )}

                  {/* Produtos e Produtividades Adicionais */}
                  {trial.additionalProducts && trial.additionalProducts.length > 0 && (
                    <div className="bg-stone-50 p-2 rounded border border-stone-200 mt-2 space-y-1.5 text-[10px]">
                      <span className="text-stone-500 block font-bold text-[8px] uppercase tracking-wider">Produtos Adicionais no Teste:</span>
                      <div className="space-y-1">
                        {trial.additionalProducts.map((addProd) => (
                          <div key={addProd.id} className="flex items-center justify-between border-b border-stone-200/50 pb-1 last:border-0 last:pb-0 gap-1.5">
                            <div className="flex items-center gap-1 truncate">
                              <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${addProd.category === 'Tche' ? 'bg-emerald-500' : 'bg-amber-500'}`} />
                              <span className="font-semibold text-stone-800 truncate" title={addProd.name}>{addProd.name}</span>
                              <span className="text-[7.5px] text-stone-400 font-bold uppercase shrink-0">({addProd.category === 'Tche' ? 'Tchê' : 'Padrão'})</span>
                            </div>
                            <div className="flex items-center gap-1 shrink-0 text-[10px] font-mono">
                              {addProd.bagsPerHa !== undefined && (
                                <span className="bg-green-100 text-green-900 font-extrabold px-1 rounded">
                                  {addProd.bagsPerHa} sc/ha
                                </span>
                              )}
                              {addProd.harvestedArea !== undefined && (
                                <span className="text-[8.5px] text-stone-450">
                                  ({addProd.harvestedArea} ha)
                                </span>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Conversão em Vendas */}
                  {trial.convertedToSale && (
                    <div className="bg-emerald-50 text-emerald-800 border border-emerald-150/60 p-2 rounded text-[10px] flex items-center justify-between font-semibold mt-2">
                      <span className="flex items-center gap-1 font-bold text-[8.5px] uppercase tracking-wide">💰 Venda Convertida:</span>
                      <span className="font-extrabold text-emerald-900 bg-emerald-100 px-1.5 py-0.5 rounded text-[10px]">
                        {trial.saleValue ? `R$ ${trial.saleValue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}` : 'Sim'}
                      </span>
                    </div>
                  )}

                  {/* Observações */}
                  {trial.notes && (
                    <div className="bg-amber-50/40 p-2 rounded border border-amber-100 mt-2 text-[10px] text-stone-650">
                      <span className="text-amber-800 font-bold block text-[8px] uppercase tracking-wider mb-0.5">Observações:</span>
                      <p className="italic line-clamp-2">{trial.notes}</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Card Footer dates summary */}
              <div className="mt-4 pt-3 border-t border-stone-200 flex items-center justify-between text-[10px] text-stone-500 font-mono">
                <div className="space-y-0.5">
                  <div>
                    <span className="text-stone-400">Plantio: </span>
                    <span className="font-semibold text-stone-650">{formatDateBR(trial.sowingDate)}</span>
                  </div>
                  <div>
                    <span className="text-stone-400">Aplicação: </span>
                    <span className="font-semibold text-stone-650">{formatDateBR(trial.applicationDate) || 'Não realizada'}</span>
                  </div>
                </div>
                {trial.harvestDate && (
                  <div className="text-right">
                    <span className="text-stone-400 block text-[9px] uppercase tracking-wider">Colheita:</span>
                    <span className="font-bold text-stone-700">{formatDateBR(trial.harvestDate)}</span>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
